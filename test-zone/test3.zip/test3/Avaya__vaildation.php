<html>
<head>

<title>Login Avaya TARDY</title>

</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>

</style>

<body>

<?php

include 'headerr.html';


//ob_start();
//session_start();




    //$user = $_COOKIE['user'];
//echo "$user";
		
    //$user = $_SESSION['user'];
	//echo "<p>Welcome : $user</p>";
		

		if(isset($_POST['submit'])){

         

           
            header("Location: index.php");
}







		if(isset($_POST['addir'])){

   
            header("Location: addir1.php");
}


if(isset($_POST['adduser'])){

         

           
            header("Location: Add_New_User.php");
}


if(isset($_POST['check'])){

$text="";
 if ($_SERVER['REQUEST_METHOD'] == "POST") {
 	
 	$myfile = fopen('myfile.html', 'r');
    $text = fread( $myfile , filesize('myfile.html'));
 	fclose($myfile);
 
}
}
ob_end_flush();
//require_once('connect.php');
?>
<form method="post">


<br>
<br>

<div class="addnew" style="background-color: gray; width: 70%;  position: relative; left:15%;">
<td>

<input type="submit" value="Add New" name="addir" style="width: 80px; height:50px;">
</td>
<td>

<input type="submit" value="Check Avail" name="check"  style="width: 120px; height:50px;">
</td>

<td>

<input type="submit" value="Add New User" name="adduser" style="width: 150px; height:50px;">
</td>

<input type="submit"  name="submit" value="Log out"  style="position: relative; left:45%; width:10%;">
</div>
<div>
	

</div>
<br>

<form name="Copyright">
<div>
		<center>
		<details>
<summary style="scale:120px right; color: black; position: relative; font-size: 15px; font-family: 'Brush Script MT', cursive;">© Copyright 2021/2022</summary>

  <p style="color: black; font-size: 11px;  font-family: 'Brush Script MT', cursive;">Powered By MGAX <br> Last update at 7-1-2022 </p>
  <?php require_once('connect.php'); ?>
</details>
</center>
	</div>

<p>Hi</p>

<div>
	
	<?php

    echo @$text;

	?>
</div>
	

</form>

</form>
</body>
</html>