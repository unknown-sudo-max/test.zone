<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aghis";

$conn = mysqli_connect($servername , $username , $password , $dbname);
if ($conn) {
	# code...

	echo "<p style='color:green; padding:10px;'>متصل_بالخادم</p><br>";
	}
        else{

        	echo "<p style=color:red>connection_failed :</p> <br>"  . mysqli_connect_error() ."<br>";
            
	//die('<p style=color: red>connection_failed :</p>' . mysqli_connect_error());
}
