<html  >
<head>
<?php

// require_once('connect.php');
include 'edit2script.php';

require_once('header.php');

// include 'access.php';
access('ADMIN');
 



?>
<title>Edit</title>

</head>
<link rel="stylesheet" href="ircss.css">

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<link href="cdn/select2.min.css" rel="stylesheet" />
<script src="cdn/select2.min.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-css/1.4.6/select2-bootstrap.min.css" integrity="sha512-3//o69LmXw00/DZikLz19AetZYntf4thXiGYJP6L49nziMIhp6DVrwhkaQ9ppMSy8NWXfocBwI3E8ixzHcpRzw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


 <script type="text/javascript">
   
   $document().ready(function() {
     var userstype = ['admin','user'];

     $('#usertype').select2({
      data:userstype;
     });
   });
 </script>

<style type="text/css">
  


  table {
   font-family: Georgia, serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
 
.body{
    position: absolute;
    right: 33%;
    width: 50%;
}


 .w3-sidebar{

     position: relative;
     right: 0;
     top: 0;
  }

   .sessiondiv{

    position: relative;
    top:  -13px;

   }

     header{

  position: absolute;
  left: 0;
  padding: 10px;

  }


    .logomain {
    width: 60%;
    position: absolute;
    right: -64px;
    top: -140px;
    z-index: -1;
    cursor: pointer;
}
  
 #delete{
  background-color: red;
  color: white;
 
  

 }
 #delete:hover{
  background-color: gray;
   
 }
 #delete:after{
  content: "\2718";
 }

details > summary {
  list-style: none;
}


  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){



  }
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){

.body{
  position: relative; 
  left: -50%; 

  top: 80px;

  width:200%;
}


 body{
    width: 40%;
    position: absolute;
    left: 30%;
   }

 }
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

.body{
  position: relative; 
  left: -50%; 

  top: 60px;

  width:200%;
}

body{
    width: 40%;
    position: absolute;
    left: 30%;
   }



}
</style>

 <?php
  require_once  'access.php';
  include 'cups.php';
      if (access('ACC' , false) || access('HR' , false) || access('EO' , false)): ?> 

<body dir="ltr">

<div class="body">
<?php
@ob_start(); 
/*

fullname
pcuser
pcpass
login
shifttime
sitestatus
arrivalstatus

*/








@session_start();



    

ob_end_flush();
?>
          
<!--

<div class="addnewbox" style="position:relative; left: 30%; width:40%; height:80%; background-color: gray;">


<tr>


<td>

<br>


<th>

<p>your name : </p>
</th>
</td>
<td>
<input type="text"  width:20PX; placeholder="" >
</td>
</tr>
</div>
  -->
<!--Connection-->  <!--Connection-->
<co class="co">
<?php

require_once('connect.php');


?>
</co>
<!-- </co> -->

  <h3 style="text-align: center; font-size: 230%; font-family: cursive;" id="ht">( Delete Users Area )</h3>
<hr color="black" size="5">
<br><br>


<form method="post" name="myform">
<div class="rnr-brickcontents style1 rnr-b-wrapper  rnr-wrapper rnr-cbw-fields">

<div class="rnr-cw-fields rnr-s-fields asbuttons MetroOffice">
<div class="rnr-c rnr-cv rnr-c-fields">


<div class="rnr-brickcontents style2 rnr-b-addheader "><span> <h1>Delete Users Area</h1>
</span></div>
<div class="rnr-brickcontents style2 rnr-b-addheader "><span> <h1> Adminstrator Users Permission</h1>
</span></div>


<div class="rnr-brickcontents style1 rnr-b-addfields_simple "><div class="rnr-simplefields edit">



<div data-fieldname="Ticket" class="rnr-field style1 ">
  <span class="rnr-label">The User</span>
  <span class="rnr-control style3"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="user1" style="width: 200px;" type="text" name="user1" value="">&nbsp;<font color="red">*</font></span></span>
</div>


  
  <!--
<div data-fieldname="action_list" class="rnr-field style1 ">
  <span class="rnr-label">Your PC User </span>
  <span class="rnr-control style3"><span id="edit1_action_list_0" class="rnr-nowrap"><select size="1" id="pcuser" name="pcuser" style="width: 207px"><option value="" hidden="">Please select</option><option value="TMP177714">TMP177714</option><option value="TMP219011">TMP219011</option><option value="TMP178527">TMP178527</option><option value="MM189185">MM189185</option><option value="TMP174168">TMP174168</option><option value="TMP175071">TMP175071</option><option value="046">046</option><option value="047">047</option><option value="048">048</option><option value="050">050</option><option value="055">055</option><option value="057">057</option><option value="062">062</option><option value="064">064</option><option value="065">065</option><option value="066">066</option><option value="068">068</option><option value="069">069</option><option value="082">082</option><option value="084">084</option><option value="086">086</option><option value="088">088</option><option value="092">092</option><option value="093">093</option><option value="095">095</option><option value="096">096</option><option value="097">097</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

 -->
  
<div data-fieldname="Ticket" class="rnr-field style1 ">
  <span class="rnr-label">The User Level</span>
  <span class="rnr-control style3"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="type" style="width: 200px; background-color: #D8D7D7; color: black;" type="text" name="type" value="" readonly="">&nbsp;<font color="red">*</font></span></span>
</div>

<!--
  
<div data-fieldname="escalate" class="rnr-field style1 ">
  <span class="rnr-label">Your Login ID</span>
  <span class="rnr-control style3"><span id="edit1_escalate_0" class="rnr-nowrap"><select size="1" id="login" name="login" style="width: 207px"><option value="">Please select</option><option value="602741">602741</option><option value="613051">613051</option><option value="86562">86562</option><option value=" 602257"> 602257</option><option value="603868">603868</option><option value="Business Support">Business Support</option><option value="I-Care">I-Care</option><option value="OLS">OLS</option><option value="SLS">SLS</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="cat" class="rnr-field style1 ">
  <span class="rnr-label">Your shift Time</span>
  <span class="rnr-control style3"><span id="edit1_cat_0" class="rnr-nowrap"><select size="1" id="shifttime" name="shifttime" style="width: 207px"><option value="">Please select</option><option value="10 AM">10 AM</option><option value="11 AM">11 AM</option><option value="1 PM">1 PM</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="prob_stat" class="rnr-field style1 ">
  <span class="rnr-label">Site Status</span>
  <span class="rnr-control style3"><span id="edit1_prob_stat_0" class="rnr-nowrap"><select size="1" id="sitestatus" name="sitestatus" style="width: 207px"><option value="">Please select</option><option value="Yes">Yes</option><option value="No">No</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  -->
  <!--
<div data-fieldname="Called" class="rnr-field style1 ">
  <span class="rnr-label">Arrival Status</span>
  <span class="rnr-control style3"><span id="edit1_Called_0" class="rnr-nowrap"><select size="1" id="arrivalstatus" name="arrivalstatus" style="width: 207px"><option value="">Please select</option><option value="On Time">On Time</option><option value="Early">Early</option><option value="Late">Late</option></select>&nbsp;<font color="red">*</font></span></span>
</div>


<div data-fieldname="Called" class="rnr-field style1 ">
  <span class="rnr-label">Recoed Status</span>
  <span class="rnr-control style3"><span id="edit1_Called_0" class="rnr-nowrap"><select size="1" id="recordstatus" name="recordstatus" style="width: 207px"><option value="">Please select</option><option value="Open">Open</option><option value="In-progress">In-progress</option><option value="Closed-Handeled">Closed-Handeled</option></select>&nbsp;<font color="red">*</font></span></span>
</div>


<div data-fieldname="Called" class="rnr-field style1 ">
  <span class="rnr-label">Comment</span>
  <span class="rnr-control style3"><textarea placeholder="Enter Your Comment ......." name="comment" id="comment" rows="3" cols="30"></textarea>
  </span>
</div>


<div data-fieldname="Called" class="rnr-field style1 ">
  <span class="rnr-label">Shift on Date</span>
  <span class="rnr-control style3"><span id="edit1_Called_0" class="rnr-nowrap">
    

<input type="date" id="start" name="shiftondate"
       value="<?php  date_default_timezone_set('Africa/Cairo'); echo date('Y-m-d'); ?>"
       min="2022-01-01" max="2025-12-31" required="">
  </span></span>
</div>




<div data-fieldname="Called" class="rnr-field style1 ">
  <span class="rnr-label">Date Now</span>
  <span class="rnr-control style3"><span id="edit1_Called_0" class="rnr-nowrap">
    <div>
    <textarea  name="addedon"  id="addedon"  value="<?php date_default_timezone_set('Africa/Cairo'); $addedon = date('d/m/Y, h:i:s A');?>"  readonly="" style="background-color: #D8D7D7; color: black;" rows="1" cols="30"/>
 <?php

echo($addedon);
?>
</textarea>
</div>
  </span></span>
</div>

  -->

<!--
  



  





<div data-fieldname="SMS" class="rnr-field style1 ">
  <span class="rnr-label">SMS</span>
  <span class="rnr-control style3"><span id="edit1_SMS_0" class="rnr-nowrap"><input id="value_SMS_1" type="hidden" name="value_SMS_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_0" name="radio_SMS_1" value="1"> <span id="label_radio_SMS_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_1" name="radio_SMS_1" value="0"> <span id="label_radio_SMS_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Ststus" class="rnr-field style1 ">
  <span class="rnr-label">Ticket Status</span>
  <span class="rnr-control style3"><span id="edit1_Ststus_0" class="rnr-nowrap"><select size="1" id="value_Ststus_1" name="value_Ststus_1" style="width: 207px"><option value="">Please select</option><option value="Open">Open</option><option value="Waiting For Response">Waiting For Response</option><option value="In-progress">In-progress</option><option value="Waiting For Customer">Waiting For Customer</option><option value="Call Back">Call Back</option><option value="Offline">Offline</option><option value="MSAN Replace">MSAN Replace</option><option value="Major Faults">Major Faults</option><option value="Internal Wiring Vendor Visit">Internal Wiring Vendor Visit</option><option value="Major Fault (Direct)">Major Fault (Direct)</option><option value="Engineering inspection ÊÝÊíÔ åäÏÓì">Engineering inspection ÊÝÊíÔ åäÏÓì</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_process" class="rnr-field style1 ">
  <span class="rnr-label">Follow Process</span>
  <span class="rnr-control style3"><span id="edit1_follow_process_0" class="rnr-nowrap"><input id="value_follow_process_1" type="hidden" name="value_follow_process_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_0" name="radio_follow_process_1" value="Yes"> <span id="label_radio_follow_process_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_1" name="radio_follow_process_1" value="No"> <span id="label_radio_follow_process_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="on_shift" class="rnr-field style1 ">
  <span class="rnr-label">On Shift</span>
  <span class="rnr-control style3"><span id="edit1_on_shift_0" class="rnr-nowrap" style="display: none;"><input id="value_on_shift_1" type="hidden" name="value_on_shift_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_0" name="radio_on_shift_1" value="1"> <span id="label_radio_on_shift_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_1" name="radio_on_shift_1" value="0"> <span id="label_radio_on_shift_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_up_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Date</span>
  <span class="rnr-control style3"><span id="edit1_follow_up_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_up_time_1" type="hidden" name="type_follow_up_time_1" value="date11"><input id="value_follow_up_time_1" style="width: 200px;" type="Text" name="value_follow_up_time_1" value=""><input id="tsvalue_follow_up_time_1" type="Hidden" name="tsvalue_follow_up_time_1" value="0-0-0">&nbsp;<a href="#" id="imgCal_value_follow_up_time_1" data-icon="calendar" title="Click Here to Pick up the date"></a></span></span>
</div>

  
<div data-fieldname="follow_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Time</span>
  <span class="rnr-control style3"><span id="edit1_follow_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_time_1" style="width: 200px;" type="hidden" name="type_follow_time_1" value="time"><input type="text" style="width: 200px;" name="value_follow_time_1" id="value_follow_time_1" value="">&nbsp;<a class="rnr-imgclock" data-icon="timepicker" title="Time" style="display: inline-block; margin: 4px 0px 0px 6px; visibility: visible;" id="trigger-test-value_follow_time_1"></a>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Comment" class="rnr-field style1 ">
  <span class="rnr-label">Comment</span>
  <span class="rnr-control style3"><span id="edit1_Comment_0" class="rnr-nowrap"><textarea id="value_Comment_1" name="value_Comment_1" style="width: 200px;height: 100px;"></textarea></span></span>
</div>

  
<div data-fieldname="integration_problem" class="rnr-field style1 ">
  <span class="rnr-label">Integration Problem</span>
  <span class="rnr-control style3"><span id="edit1_integration_problem_0" class="rnr-nowrap"><input id="type_integration_problem_1" type="hidden" name="type_integration_problem_1" value="checkbox"><input id="value_integration_problem_1" type="Checkbox" name="value_integration_problem_1"></span></span>
</div>

  
<div data-fieldname="new_pilot" class="rnr-field style1 ">
  <span class="rnr-label">Valid for proactive concession</span>
  <span class="rnr-control style3"><span id="edit1_new_pilot_0" class="rnr-nowrap" style="display: none;"><select size="1" id="value_new_pilot_1" name="value_new_pilot_1" style="width: 207px"><option value="">Please select</option><option value="Yes">Yes</option><option value="No">No</option></select></span></span>
</div>

</div>
</div>
-->


<div class="rnr-brickcontents style2 rnr-b-addbuttons "><div class="rnr-buttons-left">
    
  
  <input type="submit" class="rnr-button main" style="cursor: pointer;"  name="delete" id="delete" value="Delete">
  
  
  <input type="submit" class="rnr-button main" style="cursor: pointer;"  name="check" id="check" value="check" > 
  
  
  <a  onclick="history.back();"  class="rnr-button" style="cursor: pointer;" name="back" id="backButton1">Back to list</a>

  <!--<input type="submit" class="rnr-button main" name="delete" id="delete" style="position: relative; left: 70px;" value="Delete">-->
  


</div>
</div>


</div>
</div>

</div>



</form>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>



<script>
$(document).ready(function(){
  $("tr").on({
    mouseenter: function(){
      $(this).css("background-color", "F5CECE");
    },  
    mouseleave: function(){
      $(this).css("background-color", "FEFEFE");

    }  
  });
  
  
  
  $("tr:nth-child(even)").on({
    mouseenter: function(){
      $(this).css("background-color", "898181");
    },  
    mouseleave: function(){
      $(this).css("background-color", "CECACA");

    }  
  });
});
</script>



<?php
require_once('connect.php');
//include 'updatescript.php';

include 'usersdb.php';
include 'dusa.php';

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>



<script>
$(document).ready(function(){
  $("tr").on({
    mouseenter: function(){
      $(this).css("background-color", "F5CECE");
    },  
    mouseleave: function(){
      $(this).css("background-color", "FEFEFE");

    }  
  });
  
  
  
  $("tr:nth-child(even)").on({
    mouseenter: function(){
      $(this).css("background-color", "898181");
    },  
    mouseleave: function(){
      $(this).css("background-color", "CECACA");

    }  
  });
});
</script>



<?php

//////////////////////////
//////////////////////////host checker........../////

























//////////////////////////
ob_start();

@session_start();
@$_SESSION['fullname'] = $_GET['fullname'];
@$_SESSION['pcuser'] = $_GET['pcuser'];
@$_SESSION['pcpass'] = $_GET['pcpass'];
@$_SESSION['login'] = $_GET['login'];
@$_SESSION['shifttime'] = $_GET['shifttime'];
@$_SESSION['sitestatus'] = $_GET['sitestatus'];
@$_SESSION['arrivalstatus'] = $_GET['arrivalstatus'];
@$_SESSION['shiftondate'] = $_GET['shiftondate'];
@$_SESSION['addedon'] = $_GET['addedon'];
@$_SESSION['recordstatus'] = $_GET['recordstatus'];
@$_SESSION['comment'] = $_GET['comment'];
@$_SESSION['lastupdateby'] = $_GET['lastupdateby'];

//$_SESSION['myform'] = $_GET['myform'];
//@$_SESSION['alltxt'] = $_GET['alltxt'];


/*

if(isset($_GET['check'])){

@$fullname       = $_GET['fullname'];
@$pcuser        = $_GET['pcuser'];
@$pcpass        = $_GET['pcpass'];
@$login         = $_GET['login'];
@$shifttime     = $_GET['shifttime'];
@$sitestatus    = $_GET['sitestatus'];
@$arrivalstatus = $_GET['arrivalstatus'];
@$recordstatus  = $_GET['recordstatus'];
@$comment       = $_GET['comment'];
@$shiftondate   = $_GET['shiftondate'];
@$addedon       = $_GET['addedon'];


$sql = "INSERT INTO records (fullname, pcuser, pcpass, login, shifttime, sitestatus, arrivalstatus, recordstatus, comment, shiftondate,  addedon) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
$stmtinsert = $db->prepare($sql);
$result = $stmtinsert->execute([$fullname, $pcuser, $pcpass, $login, $shifttime, $sitestatus, $arrivalstatus, $recordstatus, $comment, $shiftondate, $addedon  ]);
if ($result) {
  # code...
  echo "Data has been saved";
}
else{
  echo "there is error appered";
}
}

*/

/*

if(isset($_GET['check'])){

   
$fullname = $_SESSION['fullname'];
   
$pcuser = $_SESSION['pcuser'];
   
$pcpass = $_SESSION['pcpass'];
   
$login = $_SESSION['login'];
   
$shifttime = $_SESSION['shifttime'];
   
$sitestatus = $_SESSION['sitestatus'];

$arrivalstatus = $_SESSION['arrivalstatus'];

$shiftondate = $_SESSION['shiftondate'];

$addedon = $_SESSION['addedon'];

$recordstatus = $_SESSION['recordstatus'];

$comment = $_SESSION['comment'];


  //echo "Full Name : $fullname<br><br>PC User : $pcuser <br><br>PC Pass : $pcpass<br><br>Login : $login<br><br>Shift Time : $shifttime<br><br>Site Status : $sitestatus<br><br>Arrival Status :$arrivalstatus<br><br>Record Status : $recordstatus<br><br>Comment : $comment<br><br>Shift on Date : $shiftondate<br><br>Added Time : $addedon<br> <hr>";


  echo "
<style>
td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

<center>
<hr>
<hr>

<div style='position: relative;text-align: center;'>
<h1 style='font-size: 19px; font:bold; '>
#_Check_Logs
</h1>
<br>
<h4 style='font-size: 15px; font:bold; font-family: Brush Script MT, cursive;' >
#_Record_Found
</h4>
</div>

<hr>
  <table  id='myTable' style='width:210%; font-size: 15px; position:relative; left: -288px;'>
  <tr>
    <th>Full Name</th>
    <th>PC User</th>
    <th>PC Pass</th>
    <th>Login</th>
    <th>Shift Time</th>
    <th>Site Status</th>
    <th>Arrival Status</th>
    <th>Record Status</th>
    <th>Comment</th>
    <th>Shift on Date</th>
    <th>Added Time</th>
  </tr>
  <tr>
<td>$fullname</td>
<td>$pcuser</td>
<td>$pcpass</td>
<td>$login</td>
<td>$shifttime</td>
<td>$sitestatus</td>
<td>$arrivalstatus</td>
<td>$recordstatus</td>
<td>$comment</td>
<td>$shiftondate</td>
<td>$addedon</td>
</tr>
</table>
</center>
<hr style='width=250px;'>

  ";
           
           
}

*/

/*
if(isset($_GET['check'])){


 if ($_SERVER['REQUEST_METHOD'] == "GET") {
  
  $myfile = fopen('myfile.txt', 'w');
    fwrite($myfile , $_GET['alltxt']);
  fclose($myfile);
 
}
}
*/
/*
if(isset($_GET['check'])){

extract($_REQUEST);
$file=fopen('myfile.html' , 'a');
fwrite($file, "Full Name : ");
fwrite($file, $fullname ."<br>");
fwrite($file, "PC User : ");
fwrite($file, $pcuser ."\n");
fwrite($file, "PC Pass : ");
fwrite($file, $pcpass ."\n");
fwrite($file, "Login : ");
fwrite($file, $login ."\n");
fwrite($file, "Shift Time : ");
fwrite($file, $shifttime ."\n");
fwrite($file, "Site Status : ");
fwrite($file, $sitestatus ."\n");
fwrite($file, "Arrival Status : ");
fwrite($file, $arrivalstatus ."\n");
fwrite($file, "<hr><hr>");
fwrite($file, "------------------------------------------------------");

fclose($myfile);


}

*/

/*
if(isset($_GET['save'])){

extract($_REQUEST);
$file=fopen('myfile.html' , 'a');
fwrite(@$file, "\n");
fwrite(@$file, "\n");
fwrite(@$file, "<!--");
fwrite(@$file, $fullname);
fwrite(@$file, "-->");
fwrite(@$file, "\n");
fwrite(@$file, "<tr>");
//fwrite(@$file, "Full Name : ");
//fwrite(@$file, "<td><img  src='edit.jpg' style='width:24px; position:relative; top:3px;'></img>");
fwrite(@$file, "<td><a href='addir1.php'><img src='edit.jpg' alt='Edit' style='width:24px; position:relative; top:3px;'>
</a>");

fwrite(@$file, $fullname);
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "PC User : ");
fwrite(@$file, $pcuser ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "PC Pass : ");
fwrite(@$file, $pcpass ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Login : ");
fwrite(@$file, $login ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Shift Time : ");
fwrite(@$file, $shifttime ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Site Status : ");
fwrite(@$file, $sitestatus ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Arrival Status : ");
fwrite(@$file, $arrivalstatus ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Record Status : ");
fwrite(@$file, $recordstatus ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Comment : ");
fwrite(@$file, $comment ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Shift on Date : ");
fwrite(@$file, $shiftondate ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Added Time : ");
fwrite(@$file, $addedon ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "</tr>");
//fwrite(@$file, "<hr><hr>");
fwrite(@$file, "\n");
fwrite(@$file, "\n");

}




*/




ob_end_flush();
?>

<script type="text/javascript">
  /*
document.GETElementById('comment').innerHTML=(myform.recordstatus[myform.recordstatus.selected].text)
*/


</script>
<script type='text/javascript'>

  /*
  $(function() {

    $('#check').click(function(e) {

      var valid = this.form.checkValidity();
      if (valid) {


      var fullname      = $('#fullname').val();
      var pcuser        = $('#pcuser').val();
      var pcpass        = $('#pcpass').val();
      var login         = $('#login').val();
      var shifttime     = $('#shifttime').val();
      var sitestatus    = $('#sitestatus').val();
      var arrivalstatus = $('#arrivalstatus').val();
      var recordstatus  = $('#recordstatus').val();
      var comment       = $('#comment').val();
      var shiftondate   = $('#shiftondate').val();
      var addedon       = $('#addedon').val();
      


        e.preventDefault();
        $.ajax({

          type: 'GET',
          url:  'check.php',
          data: {fullname : fullname,pcuser : pcuser,pcpass : pcpass,login : login,shifttime : shifttime,sitestatus : sitestatus,arrivalstatus : arrivalstatus,recordstatus : recordstatus,comment : comment,shiftondate : shiftondate,addedon : addedon},
          success: function (data) {
            // body...

            Swal.fire({
                             icon: 'success',
                             title: 'Data has been saved',
                             text: data
                             
                             
                             })
          },
          error: function (data) {
            // body...

            Swal.fire({
                             icon: 'error',
                             title: 'Oops...',
                             text: 'Something went wrong!',
                             footer: '<a href="">Why do I have this issue?</a>'
                             })
          }

        });
        //alert('true');

      }
      //else{
        //alert('false');
      //}


      

    });
  });
 
*/

</script>
<?php








  
// $r = mysqli_query($conn , $slecetr= "SELECT * FROM hruploadedfiles");



?>


  <?php




  if(isset($_GET['check'])){

 


    echo "<form>
  

  <table  id='myTable' style='width:99.9%; font-size: 15px; position: relative; left: -15%;'>
  <tr>
    <th style='background-color :#2E2D2D; color:white;'>Record ID</th>
    <th style='background-color :#2E2D2D; color:white;'>Full Name</th>
    <th style='background-color :#2E2D2D; color:white;'>PC User</th>
    <th style='background-color :#2E2D2D; color:white;'>PC Pass</th>
    <th style='background-color :#2E2D2D; color:white;'>Login</th>
    <th style='background-color :#2E2D2D; color:white;'>Shift Time</th>
    <th style='background-color :#2E2D2D; color:white;'>Site Status</th>
    <th style='background-color :#2E2D2D; color:white;'>Arrival Status</th>
    <th style='background-color :#2E2D2D; color:white;'>Record Status</th>
    <th style='background-color :#2E2D2D; color:white;'>Comment</th>
    <th style='background-color :#2E2D2D; color:white;'>Shift on Date</th>
    <th style='background-color :#2E2D2D; color:white;'>Added By</th>
    <th style='background-color :#2E2D2D; color:white;'>Last Update By</th>
    <th style='background-color :#2E2D2D; color:white;'>Added Time</th>
  </tr>";
    while (@$row = mysqli_fetch_array(@$r)){


      echo "<tr>";



      echo "<td>$row[id]</td>";
      echo "<td>$row[fullname]</td>";
      echo "<td>$row[pcuser]</td>";
      echo "<td>$row[pcpass]</td>";
      echo "<td>$row[login]</td>";
      echo "<td>$row[shifttime]</td>";
      echo "<td>$row[sitestatus]</td>";
      echo "<td>$row[arrivalstatus]</td>";
      echo "<td>$row[recordstatus]</td>";
      echo "<td>$row[comment]</td>";
      echo "<td>$row[shiftondate]</td>";
      echo "<td>$row[addedby]</td>";
      echo "<td>$row[lastupdateby]</td>";
      echo "<td>$row[addedon]</td>";
      


      echo "</tr>";

    }
}
  ?>

  <script type="text/javascript">



    
    var tbl = document.GETElementById('myTable');

    for (var x = 1 ;  x < tbl.rows.length ; x++ ){

      tbl.rows[x].onclick = function () {
        // body...

        document.GETElementById('id').value = this.cells[0].innerHTML;
        document.GETElementById('fullname').value = this.cells[1].innerHTML;
        document.GETElementById('pcuser').value = this.cells[2].innerHTML;
        document.GETElementById('pcpass').value = this.cells[3].innerHTML;
        document.GETElementById('login').value = this.cells[4].innerHTML;
        document.GETElementById('shifttime').value = this.cells[5].innerHTML;
        document.GETElementById('sitestatus').value = this.cells[6].innerHTML;
        document.GETElementById('arrivalstatus').value = this.cells[7].innerHTML;
        document.GETElementById('recordstatus').value = this.cells[8].innerHTML;
        document.GETElementById('comment').value = this.cells[9].innerHTML;
        document.GETElementById('shiftondate').value = this.cells[10].innerHTML;
        document.GETElementById('addedon').value = this.cells[13].innerHTML;
      }
    }

  </script>
</form>
</div>
<span class="printuser">Al-Agouza_Hospital</span>

</body>
<?php endif;?>
</html>