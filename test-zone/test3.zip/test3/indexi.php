<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
<link href='https://fonts.googleapis.com/css?family=Big Shoulders Inline Text' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Sedgwick Ave' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Megrim' rel='stylesheet'>

<link href='https://fonts.googleapis.com/css?family=Londrina Shadow' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Londrina Sketch' rel='stylesheet'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<script type="text/javascript">

  $(document).ready(function(){

//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.history.pushState("/indexi.php", "", '/');
}, 0);


window.scrollTo(1000,0);

});




</script>

<style>


* {box-sizing: border-box;}

body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
   overflow: scroll;
}

#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 40px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  height: 20%;
  top: 0;
  z-index: 99;
  border-radius: 3px;
  opacity: 0.9;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
    position: relative;
  top: -210%;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
}

.container a.active {
  background-color: #2196F3;
  color: white;
}
.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 400px;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.cpr{

  padding: 12px;
  margin: 12px;
  position: relative;

  text-align: center;
}



.logo{
 
  display: block;
  position: absolute;
  float: left;
  left: 0;
  top: 0;
  width: 19%;
  height: 100%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}





.test{


    position: -webkit-sticky;
  position: sticky;
  top: -20;
  
  padding: 50px;
  font-size: 20px;
}

details > summary {
  list-style: none;
}

@media screen and (max-width: 580px) {
  #navbar {
    padding: 10px 10px !important;
    height: 30%;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;

  }
  #navbar-right {
    float: right;
    position: relative;
    
  }

   
  

}
</style>
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->

<!--Micheal Test Al-Agouza Hospital HR Public Folder-->

</head>
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->

<body>

<div id="navbar">

  <a href="#default" id="logo" style="  font-family: 'Londrina Shadow';">Al-Agouza Hospital</a>
  <br>

    <b   style="padding: 2px; margin: 2px; border: 10px;">(مستشفى العجوزة)</b>
    <br>
    <h5 style="font-size: 100%; position: relative;  font-family :  'Sedgwick Ave'; color: whitesmoke; font-variant-caps: petite-caps; font-weight: bold;"  >HR Public Folder</h5>

<!--
  <span  class="ar" style="font-family: Audiowide, sans-serif;">(مستشفى العجوزة)</span>
-->
  <div id="navbar-right">
    <a class="active" href="http://127.0.0.1:8080/test3/indexi.php">الرئيسية</a>
    <a href="#help">Help</a>
    <a href="/test3" title="Sign out">خروج</a>
  </div>
  
  
</div>

<div class="container" style="margin-top:40px;padding:2px 2px 20px;font-size:30px;">
<h3 style="font-variant-caps: petite-caps;" class="test">Iframe Test</h3>
  <iframe class="ifrm"  src="iframelist.php"></iframe>
</div>





<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->

<div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div>
<script>
// When the user scrolls down 80px from the top of the document, resize the navbar's padding and the logo's font size
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 60 || document.documentElement.scrollTop > 60) {
    document.getElementById("navbar").style.padding = "33px 6px";
    document.getElementById("logo").style.fontSize = "25px";
    
  } else {
    document.getElementById("navbar").style.padding = "40px 8px";
    document.getElementById("logo").style.fontSize = "30px";
  }
}
</script>
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->
<!--Micheal Test Al-Agouza Hospital HR Public Folder-->

</body>
</html>
