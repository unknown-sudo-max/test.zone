-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19 ديسمبر 2022 الساعة 15:35
-- إصدار الخادم: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aghis`
--

-- --------------------------------------------------------

--
-- بنية الجدول `patient_login_eo`
--

CREATE TABLE `patient_eo_logs` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `medical_number` varchar(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `date_of_entry` varchar(255) NOT NULL,
  `entry_type` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `sample_result` varchar(255) NOT NULL,
  `referred_center` varchar(255) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `acceptance_permission` varchar(255) NOT NULL,
  `financial_transaction` varchar(255) NOT NULL,
  `sponsor_name` varchar(255) NOT NULL,
  `health_insurance_beneficiary` varchar(255) NOT NULL,
  `scan_facility_code` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `last_edit_by` varchar(255) NOT NULL,
  `added_on` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `patient_login_eo`
--

INSERT INTO `patient_login_eo` (`id`, `unique_id`, `patient_name`, `medical_number`, `date_of_birth`, `gender`, `date_of_entry`, `entry_type`, `section`, `room`, `grade`, `sample_result`, `referred_center`, `doctor`, `specialization`, `acceptance_permission`, `financial_transaction`, `sponsor_name`, `health_insurance_beneficiary`, `scan_facility_code`, `added_by`, `last_edit_by`, `added_on`) VALUES
(11, '121922-114007-4192', 'شهاب محمد فتحي ابراهيم', '46546897132', '1994-05-08', 'ذكر', '2022-12-19', 'مجاني', '2', '3', 'اولي مميزة', 'ايجابي', 'العجوزة', 'soultan ahmed', '3', 'سي', '3', '2', 'نعم', 'jasdsjd435', 'Admin Name', '', ' 19/12/2022, 11:40:07 AM'),
(27, '121922-020723-4126', 'شهاب محمد فتحي ابراهيم', '1234564613', '1820-05-06', 'ذكر', '2022-12-19', 'مجاني', '2', '3', 'عادي', 'ايجابي', 'العجوزة', 'soultan ahmed', '2', 'لا اعرف عنه شئ', '2', '3', 'لا', 'jasdsjd435sssssdd', 'Admin Name', '', ' 19/12/2022, 02:07:23 PM'),
(28, '121922-021510-5447', 'شهاب محمد فتحي ابراهيم عبد التواب', '00001245478', '1950-03-12', 'ذكر', '2022-12-19', 'تامين', '2', '2', 'اولي عادية', 'ايجابي', 'العجوزة', 'soultan ahmed', '3', 'لا اعرف عنه شئ', '3', '2', 'نعم', 'mmmn002', 'EO User', '', ' 19/12/2022, 02:15:10 PM'),
(29, '121922-021641-2672', 'شهاب ابراهيم فتحي محمد عبد التواب ', '0008649532', '1758-04-23', 'ذكر', '2022-12-18', 'تامين', '3', '2', 'عادي', 'ايجابي', 'العجوزة', 'mohab mohamed', '2', 'سي', '3', '1', 'نعم', 'mmmn002002', 'Shehab_Mohamed', '', ' 19/12/2022, 02:16:41 PM'),
(30, '121922-030249-7078', 'محمود الامير عبد التواب', '456789321456', '1650-05-13', 'ذكر', '2022-12-06', 'تامين', '2', '2', 'اولي عادية', 'ايجابي', 'العجوزة', 'fawzy farouk', '3', 'لا اعرف عنه شئ', '2', '3', 'نعم', 'mmmn0020035', 'Shehab_Mohamed', '', ' 19/12/2022, 03:02:49 PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patient_login_eo`
--
ALTER TABLE `patient_login_eo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `medical_number` (`medical_number`),
  ADD UNIQUE KEY `unique_id` (`unique_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient_login_eo`
--
ALTER TABLE `patient_login_eo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
