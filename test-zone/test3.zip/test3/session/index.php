<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>session test</title>
</head>
<body>
	<form method="post">
<input type="text" name="user">
<input type="submit" name="submit">
</form>

<?php 

if (isset($_POST['submit'])) {
	

	session_start();

	$_SESSION['user'] = $_POST['user'];

	echo "<script> window.location.href=('profile.php');</script>";
                 
                 

}


 

?>
</body>
</html>