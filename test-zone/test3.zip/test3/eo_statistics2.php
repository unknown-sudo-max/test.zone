
  <!-- Header -->
<?php 

require_once('header.php');
// include 'access.php';
access('EO_VIEWER');

?>
<!-- End page content -->
<link rel="stylesheet" href="cdn/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });

 
  $(document).ready(function(){


  var now = new Date();
 
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;


   $('#to_date').val(today);




  function html_table_to_excel(type)
    {
        var data = document.getElementById('myTable');
        var patientname      = $('#patient_name').val();
        var fromdate      = $('#from_date').val();
       var todate      = $('#to_date').val();

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

        XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

        XLSX.writeFile(file,'From : ' +fromdate+'_To :'+todate+ '_All patient in DB eo_statistics.' + type);
    }

    const export_button = document.getElementById('export_button');

    export_button.addEventListener('click', () =>  {
        html_table_to_excel('xlsx');
    });



    


});
 


  

</script>
<style>

.row {
  margin-left:-5px;
  margin-right:-5px;
}
  
.column {
  float: left;
  width: 24%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

    td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

tr:hover {
  background-color: #85aae5;
}


* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

.cpr{

/*  padding: 12px;
  margin: 12px;
  position: absolute;*/

  text-align: center;
 cursor: not-allowed;
/*  top: 84%;
  left: 30%;*/
  
}
 
details > summary {
  list-style: none;
}



.navbarh {
  overflow: hidden;
  background-color: #333;
}

.navbarh a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


.navbarh span {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;

}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}



.export_button {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  cursor: pointer;
  
  background-color: inherit;
  font-family: inherit;
  margin: 0;
   
}

.export_button:hover {
  background-color: red;
}

.navbarh a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}





@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){


  #divco{
    overflow: scroll;
    width: 140%;
    position: relative;
  }

}

</style>



<div class="container" style="float: left" dir="ltr">

<h4 style="font-family: 'Carattere', cursive; font-size: 30px;">EO-_-List</h4>
 <div class="navbarh" id="navbarh" style="font-family: 'Reem Kufi', sans-serif;">
  <del><span disabled="">EO_LIST</span></del>

   <?php  if (access('EO'  , false)): ?> 
    <div class="dropdown">
      

    <button class="dropbtn">تسجيل 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    
      <a href="eo_list1.php">تسجيل دخول مريض </a>
      <a href="#">مش عارف لسة</a>

       
    </div>

  </div>
<?php endif; ?> 
  <a href="eo_statistics2.php">استعلامات</a>
  <a href="eo_statistics.php">الإحصاء</a>
  <a href="#">تقارير</a>
   <span >
  <button type="button" id="export_button" class="export_button">Export To Excel</button>&nbsp;<i class='fa fa-table'></i>

   </span>         

  
</div>
<div style="background-color: black; width: 54%; padding: 4px; margin: 3px; height: auto;" class="navbarh" id="navbarv">
<form  method="GET"  >
      <!-- <input type="text" placeholder="Search.." name="search" style="width: 80%;" dir="rtl"> -->
      <label style="color:white;">&nbsp;from :</label>
      <input type="date" name="from_date" id="from_date" value="<?php @$from_date =$_GET['from_date']; echo @$from_date; ?>">

      <label style="color:white;">&nbsp;to :</label>
      <input type="date" name="to_date" id="to_date">
      
      <button type="submit" name="ser_stac"><i class="fa fa-search"></i></button>
    </form>




</div>


<!-- <ul>
  <a class="list" href="eo_list1.php"><li>تسجيل دخول مريض &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </li></a>
   <hr  class="lines2" >
  <a class="list" href="hr_list2.php"><li>List 2  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
     <hr  class="lines2" >
  <a class="list" href="hr_list3.php"><li>List 3   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
     <hr  class="lines2" >
  <a class="list" href="hr_list4.php"><li>List 4   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>

      </ul>
     



       -->


<?php


 @$fromdate = strip_tags($_GET['from_date']);
  @$todate = strip_tags($_GET['to_date']);

if (isset($_GET["from_date"])) {

 include 'connect.php';
$sql1 = " SELECT count(id) AS totalex FROM patient_login_eo WHERE record_status='خروج' AND exit_date BETWEEN '$fromdate' AND '$todate'";
$sql2 = " SELECT count(id) AS totalet FROM patient_login_eo_entry_count WHERE record_status='دخول'  AND date_of_entry BETWEEN '$fromdate' AND '$todate'";
$sql30 = " SELECT count(id) AS totalex_1 FROM patient_login_eo WHERE record_status='خروج' AND exit_type = 'شفاء' AND  exit_date BETWEEN '$fromdate' AND '$todate'";
$sql31 = " SELECT count(id) AS totalex_2 FROM patient_login_eo WHERE record_status='خروج'  AND exit_type = 'تحويل' AND  exit_date  BETWEEN '$fromdate' AND '$todate'";
$sql32 = " SELECT count(id) AS totalex_3 FROM patient_login_eo WHERE record_status='خروج' AND exit_type = 'وفاة' AND exit_date BETWEEN '$fromdate' AND '$todate'";
$sql33 = " SELECT count(id) AS totalex_4 FROM patient_login_eo WHERE record_status='خروج' AND exit_type = 'هروب' AND exit_date BETWEEN '$fromdate' AND '$todate'";

$sql3 = " SELECT count(id) AS totalet_em FROM patient_login_eo_entry_count WHERE entry_type='طوارئ'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql4 = " SELECT count(id) AS totalet_di FROM patient_login_eo WHERE entry_type='مباشر'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql5 = " SELECT count(id) AS totalfts_free FROM patient_login_eo WHERE financial_transaction='مجانى'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql6 = " SELECT count(id) AS totalfts_spc FROM patient_login_eo WHERE financial_transaction='خاص'   AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql7 = " SELECT count(id) AS totalfts_hos FROM patient_login_eo WHERE financial_transaction='مستشفى'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql8 = " SELECT count(id) AS totalfts_min FROM patient_login_eo WHERE financial_transaction='وزارة'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql9 = " SELECT count(id) AS totalfts_comp FROM patient_login_eo WHERE financial_transaction='شركات'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql10 = " SELECT count(id) AS totalfts_insu FROM patient_login_eo WHERE financial_transaction='تأمين'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql11 = " SELECT count(id) AS totalfts_insu_chil FROM patient_login_eo WHERE financial_transaction='تأمين أطفال'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql12 = " SELECT count(id) AS totalfts_insu_newborn FROM patient_login_eo WHERE financial_transaction='تأمين مواليد'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql13 = " SELECT count(id) AS total_ius_y FROM patient_login_eo WHERE health_insurance_beneficiary='منتفع بالتامين'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql14 = " SELECT count(id) AS total_ius_n FROM patient_login_eo WHERE health_insurance_beneficiary='غير منتفع بالتامين'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql15 = " SELECT count(id) AS total_sect_1 FROM patient_login_eo WHERE  section='1'  AND date_of_entry  BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql16 = " SELECT count(id) AS total_sect_2 FROM patient_login_eo WHERE  section='2' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql17 = " SELECT count(id) AS total_sect_3 FROM patient_login_eo WHERE  section='3' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql18 = " SELECT count(id) AS total_sect_4 FROM patient_login_eo WHERE  section='4' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql19 = " SELECT count(id) AS total_sect_5 FROM patient_login_eo WHERE  section='5' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql20 = " SELECT count(id) AS total_sect_6 FROM patient_login_eo WHERE  section='6' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql21 = " SELECT count(id) AS total_sect_7 FROM patient_login_eo WHERE  section='7' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql22 = " SELECT count(id) AS total_sect_8 FROM patient_login_eo WHERE  section='8' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql23 = " SELECT count(id) AS total_sect_9 FROM patient_login_eo WHERE  section='9' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql24 = " SELECT count(id) AS total_sect_10 FROM patient_login_eo WHERE  section='10' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql25 = " SELECT count(id) AS total_sect_11 FROM patient_login_eo WHERE  section='11' AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql26 = " SELECT count(id) AS total_sect_12 FROM patient_login_eo WHERE  section='وحدة الأطفال المبتسرين'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql27 = " SELECT count(id) AS total_sect_13 FROM patient_login_eo WHERE  section='عناية مركزة'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql28 = " SELECT count(id) AS total_sect_14 FROM patient_login_eo WHERE  section='عناية قلب مفتوح'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";
$sql29 = " SELECT count(id) AS total_sect_15 FROM patient_login_eo WHERE  section='وحدة الانجو'  AND date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";

$exresult =mysqli_query($conn , $sql1);
$etresult =mysqli_query($conn , $sql2);
$et_em_result =mysqli_query($conn , $sql3);
$et_di_result =mysqli_query($conn , $sql4);
$fts_free_result =mysqli_query($conn , $sql5);
$fts_spc_result =mysqli_query($conn , $sql6);
$fts_hos_result =mysqli_query($conn , $sql7);
$fts_min_result =mysqli_query($conn , $sql8);
$fts_comp_result =mysqli_query($conn , $sql9);
$fts_insu_result =mysqli_query($conn , $sql10);
$fts_insu_chil_result =mysqli_query($conn , $sql11);
$fts_insu_newborn_result =mysqli_query($conn , $sql12);
$ius_y_result =mysqli_query($conn , $sql13);
$ius_n_result =mysqli_query($conn , $sql14);
$sect_1_result =mysqli_query($conn , $sql15);
$sect_2_result =mysqli_query($conn , $sql16);
$sect_3_result =mysqli_query($conn , $sql17);
$sect_4_result =mysqli_query($conn , $sql18);
$sect_5_result =mysqli_query($conn , $sql19);
$sect_6_result =mysqli_query($conn , $sql20);
$sect_7_result =mysqli_query($conn , $sql21);
$sect_8_result =mysqli_query($conn , $sql22);
$sect_9_result =mysqli_query($conn , $sql23);
$sect_10_result =mysqli_query($conn , $sql24);
$sect_11_result =mysqli_query($conn , $sql25);
$sect_12_result =mysqli_query($conn , $sql26);
$sect_13_result =mysqli_query($conn , $sql27);
$sect_14_result =mysqli_query($conn , $sql28);
$sect_15_result =mysqli_query($conn , $sql29);
$totalex_1_result =mysqli_query($conn , $sql30);
$totalex_2_result =mysqli_query($conn , $sql31);
$totalex_3_result =mysqli_query($conn , $sql32);
$totalex_4_result =mysqli_query($conn , $sql33);

$exvalues = mysqli_fetch_assoc($exresult);
$etvalues = mysqli_fetch_assoc($etresult);
$et_em_values = mysqli_fetch_assoc($et_em_result);
$et_di_values = mysqli_fetch_assoc($et_di_result);
$fts_free_values = mysqli_fetch_assoc($fts_free_result);
$fts_spc_values = mysqli_fetch_assoc($fts_spc_result);
$fts_hos_values = mysqli_fetch_assoc($fts_hos_result);
$fts_min_values = mysqli_fetch_assoc($fts_min_result);
$fts_comp_values = mysqli_fetch_assoc($fts_comp_result);
$fts_insu_values = mysqli_fetch_assoc($fts_insu_result);
$fts_insu_chil_values = mysqli_fetch_assoc($fts_insu_chil_result);
$fts_insu_newborn_values = mysqli_fetch_assoc($fts_insu_newborn_result);
$ius_y_values = mysqli_fetch_assoc($ius_y_result);
$ius_n_values = mysqli_fetch_assoc($ius_n_result);
$sect_1_values = mysqli_fetch_assoc($sect_1_result);
$sect_2_values = mysqli_fetch_assoc($sect_2_result);
$sect_3_values = mysqli_fetch_assoc($sect_3_result);
$sect_4_values = mysqli_fetch_assoc($sect_4_result);
$sect_5_values = mysqli_fetch_assoc($sect_5_result);
$sect_6_values = mysqli_fetch_assoc($sect_6_result);
$sect_7_values = mysqli_fetch_assoc($sect_7_result);
$sect_8_values = mysqli_fetch_assoc($sect_8_result);
$sect_9_values = mysqli_fetch_assoc($sect_9_result);
$sect_10_values = mysqli_fetch_assoc($sect_10_result);
$sect_11_values = mysqli_fetch_assoc($sect_11_result);
$sect_12_values = mysqli_fetch_assoc($sect_12_result);
$sect_13_values = mysqli_fetch_assoc($sect_13_result);
$sect_14_values = mysqli_fetch_assoc($sect_14_result);
$sect_15_values = mysqli_fetch_assoc($sect_15_result);

$totalex_1_values = mysqli_fetch_assoc($totalex_1_result);
$totalex_2_values = mysqli_fetch_assoc($totalex_2_result);
$totalex_3_values = mysqli_fetch_assoc($totalex_3_result);
$totalex_4_values = mysqli_fetch_assoc($totalex_4_result);
$ex_num_rows =$exvalues['totalex'];
$et_num_rows =$etvalues['totalet'];
$et_em_num_rows =$et_em_values['totalet_em'];
$et_di_num_rows =$et_di_values['totalet_di'];
$fts_free_num_rows =$fts_free_values['totalfts_free'];
$fts_spc_num_rows =$fts_spc_values['totalfts_spc'];
$fts_hos_num_rows =$fts_hos_values['totalfts_hos'];
$fts_min_num_rows =$fts_min_values['totalfts_min'];
$fts_comp_num_rows =$fts_comp_values['totalfts_comp'];
$fts_insu_num_rows =$fts_insu_values['totalfts_insu'];
$fts_insu_chil_num_rows =$fts_insu_chil_values['totalfts_insu_chil'];
$fts_insu_newborn_num_rows =$fts_insu_newborn_values['totalfts_insu_newborn'];
$ius_y_num_rows =$ius_y_values['total_ius_y'];
$ius_n_num_rows =$ius_n_values['total_ius_n'];
$sect_1_num_rows =$sect_1_values['total_sect_1'];
$sect_2_num_rows =$sect_2_values['total_sect_2'];
$sect_3_num_rows =$sect_3_values['total_sect_3'];
$sect_4_num_rows =$sect_4_values['total_sect_4'];
$sect_5_num_rows =$sect_5_values['total_sect_5'];
$sect_6_num_rows =$sect_6_values['total_sect_6'];
$sect_7_num_rows =$sect_7_values['total_sect_7'];
$sect_8_num_rows =$sect_8_values['total_sect_8'];
$sect_9_num_rows =$sect_9_values['total_sect_9'];
$sect_10_num_rows =$sect_10_values['total_sect_10'];
$sect_11_num_rows =$sect_11_values['total_sect_11'];
$sect_12_num_rows =$sect_12_values['total_sect_12'];
$sect_13_num_rows =$sect_13_values['total_sect_13'];
$sect_14_num_rows =$sect_14_values['total_sect_14'];
$sect_15_num_rows =$sect_15_values['total_sect_15'];

$totalex_1_num_rows =$totalex_1_values['totalex_1'];
$totalex_2_num_rows =$totalex_2_values['totalex_2'];
$totalex_3_num_rows =$totalex_3_values['totalex_3'];
$totalex_4_num_rows =$totalex_4_values['totalex_4'];




 
 


echo "
<div id='divco'>
<table  id=\"myTable\" style=\"width:99.9%;font-family: sans-serif; font-weight: normal;\" >";

echo "

  <th colspan=\"2\" style=\"background-color: gray; color: white;\" id=\"tth\">إحصاء مجموع كل حالات</th>
    <th colspan=\"2\" style=\"background-color: gray; color: white;\" id=\"tth1\">إحصاء مجموع انواع الدخول</th>

   <th colspan=\"8\" style=\"background-color: gray; color: white;\" id=\"tth2\">إحصاء المعاملة المالية</th>
  
 
  

  <tr>
     <th>حالات الخروج</th>
      <th>حالات الدخول</th>
        <th>طوارئ</th>
      <th>مباشر</th>
       <th>ت.م مواليد</th>
      <th>ت.م اطفال</th>
      <th>تأمين</th>
      <th>شركات</th>
      <th>وزارة</th>
      <th>مستشفى</th>
      <th>خاص</th>
      <th>مجاني</th>
  </tr>

 <tr>
  <td>$ex_num_rows</td>
    <td>$et_num_rows</td>
   
      <td>$et_em_num_rows</td>
    <td>$et_di_num_rows</td>

    <td>$fts_insu_newborn_num_rows</td>
    <td>$fts_insu_chil_num_rows</td>
    <td>$fts_insu_num_rows</td>
    <td>$fts_comp_num_rows</td>
    <td>$fts_min_num_rows</td>
    <td>$fts_hos_num_rows</td>
    <td>$fts_spc_num_rows</td>
    <td>$fts_free_num_rows</td>
  </tr>
 

  <th colspan=\"8\" style=\"background-color: gray; color: white;\" id=\"tth3\"> إحصاء الانتفاع بالتامين</th>
 <th colspan=\"8\" style=\"background-color: gray; color: white;\" id=\"tth5\">إحصاء مجموع انواع الخروج</th>

  <tr>
     <th colspan=\"4\">غير منتفع</th>
      <th colspan=\"4\">منتفع</th>
      <th colspan=\"2\">هروب</th>
      <th colspan=\"2\">وفاة</th>
      <th colspan=\"2\">تحويل</th>
      <th colspan=\"2\">شفاء</th>

  </tr>
  <tr>
    <td colspan=\"4\">$ius_n_num_rows</td>
    <td colspan=\"4\">$ius_y_num_rows</td>
     <td colspan=\"2\">$totalex_4_num_rows</td>
     <td colspan=\"2\">$totalex_3_num_rows</td>
     <td colspan=\"2\">$totalex_2_num_rows</td>
     <td colspan=\"2\">$totalex_1_num_rows</td>
  </tr>

   <th colspan=\"15\" style=\"background-color: gray; color: white;\" id=\"tth4\"> إحصاء مجموع كل حالات الأقسام</th>
  

  <tr>
     <th>الانجو</th>
      <th>قلب مفتوح</th>
      <th>عناية مركزة</th>
      <th>المبتسرين</th>
      <th>قسم 11</th>
      <th>قسم 10</th>
      <th>قسم 9</th>
      <th>قسم 8</th>
      <th>قسم 7</th>
      <th>قسم 6</th>
      <th>قسم 5</th>
      <th>قسم 4</th>
      <th>قسم 3</th>
      <th>قسم 2</th>
      <th>قسم 1</th>
      
  </tr>

 <tr>
  <td>$sect_15_num_rows</td>
    <td>$sect_14_num_rows</td>
     <td>$sect_13_num_rows</td>
    <td>$sect_12_num_rows</td>
     <td>$sect_11_num_rows</td>
    <td>$sect_10_num_rows</td>
     <td>$sect_9_num_rows</td>
    <td>$sect_8_num_rows</td>
     <td>$sect_7_num_rows</td>
    <td>$sect_6_num_rows</td>
     <td>$sect_5_num_rows</td>
    <td>$sect_4_num_rows</td>
     <td>$sect_3_num_rows</td>
    <td>$sect_2_num_rows</td>
     <td>$sect_1_num_rows</td>
    

";



 $sql = "SELECT * from patient_login_eo where exit_date BETWEEN '$fromdate' AND '$todate' OR date_of_entry BETWEEN '$fromdate' AND '$todate' ORDER BY added_on DESC";


$result = $conn->query($sql);


 
 


if ($result->num_rows > 0 ){




echo "

<tr>
 
 <th colspan=\"24\" style=\"background-color: gray; color: white;\" id=\"tth2\" hidden>سجلات المرضي من :  $fromdate الي : $todate</th>
 </tr>

  <tr>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اسم المريض </th>

    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الرقم القومي</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المريض</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تاريخ الميلاد</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>النوع</th>

   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th2\" hidden>الرقم الطبي</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اسم المرافق</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المرافق</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>درجة قرابة المرافق</th>

     <th style=\"background-color :#1c562b; color:white;font-weight: normal;\" id=\"tht\"hidden>تاريخ الدخول</th>
   <th style=\"background-color :#721d1d; color:white;font-weight: normal;\" id=\"tht\"hidden>تاريخ الخروج</th>



   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th4\"hidden>نوع الدخول</th>

   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th5\"hidden>القسم</th>

  
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الدرجة</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الطبيب</th>
   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اذن القبول</th>
   
  
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th9\"hidden>التخصص</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th10\"hidden>المعاملة المالية</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th11\"hidden>التامين</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th12\"hidden>حالة الملف</th>


    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>نوع الخروج</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تم الاضافه بواسطة </th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تم التعديل بواسطة </th>
 <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th15\" hidden>تاريخ</th>
   
   
   

    
  </tr>



";




while($row = $result->fetch_assoc() ){



 echo "<tr id='tr'>";



      echo "<td hidden>$row[patient_name]</td>";
 
      echo "<td hidden>$row[pa_national_id]</td>";
      echo "<td hidden>$row[pa_phone_num]</td>";
      echo "<td hidden>$row[date_of_birth]</td>";
      echo "<td hidden>$row[gender]</td>";
      echo "<td hidden>$row[medical_number]</td>";
      echo "<td hidden>$row[sponsor_name]</td>";
      echo "<td hidden>$row[spo_phone_num]</td>";
      echo "<td hidden>$row[spo_degree_of_kinship]</td>";
      echo "<td style='font-size:10px;' hidden>$row[date_of_entry]</td>";
      echo "<td style='font-size:10px;' hidden>$row[exit_date]</td>";
      
      echo "<td hidden>$row[entry_type]</td>";
      echo "<td hidden>$row[section]</td>";
      
      echo "<td hidden>$row[grade]</td>";
      echo "<td hidden>$row[doctor]</td>";
      echo "<td hidden>$row[acceptance_permission]</td>";
      

      
      
      echo "<td hidden>$row[specialization]</td>";
      echo "<td hidden>$row[financial_transaction]</td>";
      echo "<td hidden>$row[health_insurance_beneficiary]</td>";
      echo "<td hidden>$row[record_status]</td>";
      echo "<td hidden>$row[exit_type]</td>";

      echo "<td hidden>$row[added_by]</td>";
      echo "<td hidden>$row[last_edit_by]</td>";
      
      echo "<td hidden>$row[added_on]</td>";
      
        //echo "<td>$row[ip]</td>";
  
      


      echo "</tr>";




} 

 
} 
 echo "</table>";

}

?>




<?php


 @$search = strip_tags($_POST['search']);

if (isset($_POST["search"])) {
  include 'connect.php';

$sql = "SELECT * from patient_login_eo where (medical_number like '%$search%' OR  patient_name  like '%$search%' OR  date_of_entry  like '%$search%') ORDER BY added_on DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0){

          
echo "




<table  id=\"myTable\" style=\"width:99.9%;font-family: 'Reem Kufi', sans-serif; font-weight: normal;\">
<thead>
  <tr>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\">اسم المريض </th>

    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الرقم القومي</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المريض</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تاريخ الميلاد</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>النوع</th>

   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th2\">الرقم الطبي</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اسم المرافق</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المرافق</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>درجة قرابة المرافق</th>

     <th style=\"background-color :#1c562b; color:white;font-weight: normal;\" id=\"tht\">تاريخ الدخول</th>
   <th style=\"background-color :#721d1d; color:white;font-weight: normal;\" id=\"tht\">تاريخ الخروج</th>



   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th4\">نوع الدخول</th>

   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th5\">القسم</th>

  
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الدرجة</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الطبيب</th>
   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اذن القبول</th>
   
  
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th9\">التخصص</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th10\">المعاملة المالية</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th11\">التامين</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th12\">حالة الملف</th>


    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>نوع الخروج</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تم الاضافه بواسطة </th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تم التعديل بواسطة </th>

   
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th15\">تاريخ</th>
    
  </tr>
 </thead>


";
while($row = $result->fetch_assoc() ){


      echo "<tbody><tr id='tr'>";



      echo "<td><div style=\"position: relative; padding: 4px; margin: -4px;\">$row[patient_name]</div> <div style=\"position: relative;  display:grid;\"><a href='view2_patient_eo_logs.php?unique_id=$row[unique_id]' class=\"fa fa-search\" style=\"margin:2px; \" title='View'></a></div>"
  ?>
<?php
      if (access('EO' , false)): ?> 
        <?php
      echo " <div style=\"position: relative;  display:grid;\"><a href='edit2_patient_eo_logs.php?unique_id=$row[unique_id]' class=\"fa fa-edit\" style=\"margin:2px;\" title='Edit'></a></div></td>";
      ?>
       <?php endif; ?>
       <?php
      echo "<td hidden>$row[pa_national_id]</td>";
      echo "<td hidden>$row[pa_phone_num]</td>";
      echo "<td hidden>$row[date_of_birth]</td>";
      echo "<td hidden>$row[gender]</td>";
      echo "<td>$row[medical_number]</td>";
      echo "<td hidden>$row[sponsor_name]</td>";
      echo "<td hidden>$row[spo_phone_num]</td>";
      echo "<td hidden>$row[spo_degree_of_kinship]</td>";
      echo "<td style='font-size:10px;'>$row[date_of_entry]</td>";
      echo "<td style='font-size:10px;'>$row[exit_date]</td>";
      
      echo "<td>$row[entry_type]</td>";
      echo "<td>$row[section]</td>";
      
      echo "<td hidden>$row[grade]</td>";
      echo "<td hidden>$row[doctor]</td>";
      echo "<td hidden>$row[acceptance_permission]</td>";
      

      
      
      echo "<td>$row[specialization]</td>";
      echo "<td>$row[financial_transaction]</td>";
      echo "<td>$row[health_insurance_beneficiary]</td>";
      echo "<td>$row[record_status]</td>";
      echo "<td hidden>$row[exit_type]</td>";

      echo "<td hidden>$row[added_by]</td>";
      echo "<td hidden>$row[last_edit_by]</td>";
      
      echo "<td style='font-size:10px;'>$row[added_on]</td>";
      
        //echo "<td>$row[ip]</td>";
      


      echo "</tr> </tbody>";

 echo "</div>";


}




} else {
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;'>لا يوجد ملفات تم ارفاقها</p>";
}

$conn->close();


}

?>



 











</div>
 






<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->


<?php








if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('navbarh').style.backgroundColor = '#081a36';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('tth').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('tth1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('tth2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('tth3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('tth4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('tth5').style.backgroundColor = '#081a36';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#9ab3cd';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
            </script>";






  }elseif (@$_SESSION['type']=='eo_user') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = '#1c2827';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('tth').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('tth1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('tth2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('tth3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('tth4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('tth5').style.backgroundColor = '#1c2827';</script>";
        echo "<script>
                      document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                      document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                      function mouseEnter() {
                        document.getElementById('tr').style.backgroundColor = '#7e9996';
                      }

                      function mouseLeave() {
                        document.getElementById('tr').style.backgroundColor = '';
                      }
              </script>";


     
  }elseif (@$_SESSION['type']=='eo_viewer') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = 'gray';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('tth').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('tth1').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('tth2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('tth3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('tth4').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('tth5').style.backgroundColor = 'gray';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#c39dba';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
             </script>";

     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
