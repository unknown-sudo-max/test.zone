
  <!-- Header -->
<?php 

require_once('header.php');
// include 'access.php';
access('EO_VIEWER');

?>
<!-- End page content -->
<link rel="stylesheet" href="cdn/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });

 
  $(document).ready(function(){



 function html_table_to_excel(type)
    {
        var data = document.getElementById('myTable');

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

        XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

        XLSX.writeFile(file, 'All patient in DB file.' + type);
    }

    const export_button = document.getElementById('export_button');

    export_button.addEventListener('click', () =>  {
        html_table_to_excel('xlsx');
    });


});
 
  

</script>
<style>


    td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

tr:hover {
  background-color: #85aae5;
}


* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

.cpr{

/*  padding: 12px;
  margin: 12px;
  position: absolute;*/

  text-align: center;
 cursor: not-allowed;
/*  top: 84%;
  left: 30%;*/
  
}
 
details > summary {
  list-style: none;
}



.navbarh {
  overflow: hidden;
  background-color: #333;
}

.navbarh a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


.navbarh span {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;

}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}



.export_button {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  cursor: pointer;
  
  background-color: inherit;
  font-family: inherit;
  margin: 0;
   
}

.export_button:hover {
  background-color: red;
}

.navbarh a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}





  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }
#navbarv{
    width: 70%;
    position: relative;
  }
  }



 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }

  #navbarv{
    width: 70%;
    position: relative;
  }
   h4{
    top: 75px;
    position: relative;
  }


}


@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

  .navbarh{
    width: 130%;
    position: relative;
    top: 75px;
    height: 150px;

  }

  h4{
    top: 75px;
    position: relative;
  }

  #navbarv{
    width: 80%;
    position: relative;
  }

    #divco{
    overflow: scroll;
    width: 140%;
    position: relative;
  }

}

</style>



<div class="container" style="float: left" dir="ltr">

<h4 style="font-family: 'Carattere', cursive; font-size: 30px;">EO-_-List</h4>
 <div class="navbarh" id="navbarh" style="font-family: 'Reem Kufi', sans-serif;">
  <del><span disabled="">EO_LIST</span></del>

   
  <?php  if (access('EO'  , false)): ?> 
  <div class="dropdown">
    <button class="dropbtn">تسجيل 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    
      <a href="eo_list1.php">تسجيل دخول مريض </a>
      <a href="#">مش عارف لسة</a>

       
    </div>
  </div>
 <?php endif; ?> 
  <a href="eo_statistics2.php">استعلامات</a>
  <a href="eo_statistics.php">الإحصاء</a>
  <a href="#">تقارير</a>
   <span >
  <button type="button" id="export_button" class="export_button">Export To Excel</button>&nbsp;<i class='fa fa-table'></i>

   </span>         

 
</div>
<div  class="navbarh" id="navbarv"  style="background-color: black; padding: 4px; margin: 3px; height: auto;" >
<form  method="post" action="eo_test2.php" >
      <input type="text" placeholder="Search.." name="search" style="width: 80%;" dir="rtl">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>




</div>


<!-- <ul>
  <a class="list" href="eo_list1.php"><li>تسجيل دخول مريض &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </li></a>
   <hr  class="lines2" >
  <a class="list" href="hr_list2.php"><li>List 2  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
     <hr  class="lines2" >
  <a class="list" href="hr_list3.php"><li>List 3   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
     <hr  class="lines2" >
  <a class="list" href="hr_list4.php"><li>List 4   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>

      </ul>
     



       -->
    










<?php


 @$search = strip_tags($_POST['search']);

if (isset($_POST["search"])) {
  include 'connect.php';

$sql = "SELECT * from patient_login_eo where (medical_number like '%$search%' OR  patient_name  like '%$search%' OR  date_of_entry  like '%$search%') ORDER BY added_on DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0){

          
echo "

<div id='divco'>


<table  id=\"myTable\" style=\"width:99.9%;font-family: sans-serif; font-weight: normal;\">
  <tr>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\">اسم المريض </th>

    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الرقم القومي</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المريض</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تاريخ الميلاد</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>النوع</th>

   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th2\">الرقم الطبي</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اسم المرافق</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المرافق</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>درجة قرابة المرافق</th>

     <th style=\"background-color :#1c562b; color:white;font-weight: normal;\" id=\"tht\">تاريخ الدخول</th>
   <th style=\"background-color :#721d1d; color:white;font-weight: normal;\" id=\"tht\">تاريخ الخروج</th>



   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th4\">نوع الدخول</th>

   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th5\">القسم</th>

  
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الدرجة</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الطبيب</th>
   <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اذن القبول</th>
   
  
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th9\">التخصص</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th10\">المعاملة المالية</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th11\">التامين</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th12\">حالة الملف</th>


    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>نوع الخروج</th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تم الاضافه بواسطة </th>
<th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تم التعديل بواسطة </th>

   
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th15\">تاريخ</th>
    
  </tr>



";
while($row = $result->fetch_assoc() ){


      echo "<tr id='tr'>";



      echo "<td><div style=\"position: relative; padding: 4px; margin: -4px;\">$row[patient_name]</div> <div style=\"position: relative;  display:grid;\"><a href='view2_patient_eo_logs.php?unique_id=$row[unique_id]' class=\"fa fa-search\" style=\"margin:2px; \" title='View'></a></div>"
  ?>
<?php
      if (access('EO' , false)): ?> 
        <?php
      echo " <div style=\"position: relative;  display:grid;\"><a href='edit2_patient_eo_logs.php?unique_id=$row[unique_id]' class=\"fa fa-edit\" style=\"margin:2px;\" title='Edit'></a></div></td>";
      ?>
       <?php endif; ?>
       <?php
      echo "<td hidden>$row[pa_national_id]</td>";
      echo "<td hidden>$row[pa_phone_num]</td>";
      echo "<td hidden>$row[date_of_birth]</td>";
      echo "<td hidden>$row[gender]</td>";
      echo "<td>$row[medical_number]</td>";
      echo "<td hidden>$row[sponsor_name]</td>";
      echo "<td hidden>$row[spo_phone_num]</td>";
      echo "<td hidden>$row[spo_degree_of_kinship]</td>";
      echo "<td style='font-size:10px;'>$row[date_of_entry]</td>";
      echo "<td style='font-size:10px;'>$row[exit_date]</td>";
      
      echo "<td>$row[entry_type]</td>";
      echo "<td>$row[section]</td>";
      
      echo "<td hidden>$row[grade]</td>";
      echo "<td hidden>$row[doctor]</td>";
      echo "<td hidden>$row[acceptance_permission]</td>";
      

      
      
      echo "<td>$row[specialization]</td>";
      echo "<td>$row[financial_transaction]</td>";
      echo "<td>$row[health_insurance_beneficiary]</td>";
      echo "<td>$row[record_status]</td>";
      echo "<td hidden>$row[exit_type]</td>";

      echo "<td hidden>$row[added_by]</td>";
      echo "<td hidden>$row[last_edit_by]</td>";
      
      echo "<td style='font-size:10px;'>$row[added_on]</td>";
      
        //echo "<td>$row[ip]</td>";
      


      echo "</tr>";


echo "</div>";

}

$sql1 = " SELECT count(id) AS totalex FROM patient_login_eo WHERE record_status='خروج' ";
$sql2 = " SELECT count(id) AS totalet FROM patient_login_eo WHERE record_status='دخول' ";
$exresult =mysqli_query($conn , $sql1);
$etresult =mysqli_query($conn , $sql2);
$exvalues = mysqli_fetch_assoc($exresult);
$etvalues = mysqli_fetch_assoc($etresult);
$ex_num_rows =$exvalues['totalex'];
$et_num_rows =$etvalues['totalet'];
 echo 'خروج :' . $ex_num_rows . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'. 'دخول :' . $et_num_rows ;


} else {
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;'>لا يوجد ملفات تم ارفاقها</p>";
}

$conn->close();


}

?>



 











</div>
 






<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->


<?php








if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('navbarh').style.backgroundColor = '#081a36';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#9ab3cd';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
            </script>";






  }elseif (@$_SESSION['type']=='eo_user') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = '#1c2827';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#1c2827';</script>";
        echo "<script>
                      document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                      document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                      function mouseEnter() {
                        document.getElementById('tr').style.backgroundColor = '#7e9996';
                      }

                      function mouseLeave() {
                        document.getElementById('tr').style.backgroundColor = '';
                      }
              </script>";


     
  }elseif (@$_SESSION['type']=='eo_viewer') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = 'gray';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = 'gray';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#c39dba';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
             </script>";

     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
