
<?php 

require_once('header.php');
// include 'access.php';
access('USER');
?>
<html dir="rtl" lang="ar">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">

.demo-wrap {
  position: relative;
}

.demo-wrap:after {
  content: ' ';
  display: block;
  position: absolute;
  float: left;
  left: 0;
  top: 0;
  width: 22%;
  height: 100%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

li{
  list-style-type: none;

}

a {
  float: left;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
  background-color: #30072c;
  color: white;
  font-weight: bold;
    

}
 a:hover {
  background-color: #a5707a;
  color: black;
  font-weight: bold;
}

  .btnup{

padding: 10px;
margin: 8px;
border-radius: 5px;
border: none;
text-decoration: none;
background-color: #30072c;
  color: white;
  font-weight: bold;
    
transition-duration: 0.4s;
cursor: pointer;
left: -7px;
position: relative;

  }


  .btnup:hover{

 background-color: #a5707a;
  color: black;
  font-weight: bold;



  }
  .fn{

align-items: center;

  }

  .com{
 
 align-items: center;

  }
  .divup{
    padding: 10px;
  }


  details > summary {
  list-style: none;

}
.allofthelist{

width: 70%;
position: absolute;
float: left;
left: 3%;

}

.cpr{

  padding: 12px;
  margin: 12px;
  position: absolute;

  text-align: center;
 cursor: not-allowed;
  top: 99%;
  left: 30%;
  
}
 
details > summary {
  list-style: none;
}


  </style>

<div class="allofthelist">
  <br>
<a class="list"  onclick="history.back()"  style="cursor: pointer;"><li>السابق ←</li></a>
<br><br><br>
<hr class="lines2"><br>
<h4>List 2</h4>
<div class="divup">
  <div class="">
  <form class="fmup" method="POST"  enctype="multipart/form-data">
    <span>
<input type="file"  id="file" name="file" accept=".xls,.xlsx"   >

  <?php




$fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($fullurl, "upload=empty") == true) {


  echo "<style>


.ft{
 border-color: red;
}


  </style>";
  
  echo "<div style='position: absolute;
      text-align: right;
    font-weight: bold;
    top: 353px;
    width : 25%;
    font-size: 70%;
    left: 61%;
    color: red;
    '><i class=\"fa fa-close\" style=\"font-size:10px;color:red\"></i> <u >You Can't Leave This Field Empty !!! </u></div>";
   
  echo "<br>";
}


 
 

$fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($fullurl, "upload=Success") == true) {


  echo "<style>


.ft {
 border-color: green;
}

.fd {
 border-color: green;
}

  </style>";
  
  echo "<i class=\"fa fa-check-circle\" style=\"position: absolute; left: 48.5%; top:190px; font-size:48px;color:green\"></i> <div style='color:green; text-align: center; font-weight: bold; position: relative; ' >Your File Uploaded Successfully</div>";
  echo "<br>";
   
}


 ?>
</span>
<br><br>
<table>
  <tr>
    <tr>
 <span class="fn"><t style="font-size: 15px;">أسم الملف :</t>

  <input type="text" class="ft" style="padding: 10px; margin: 10px; border-radius: 10px;  border-style: solid; border-width: thin; background-color: #f0f0f0;" id="filetitle" name="filetitle"  placeholder="اسم الملف"   autofocus>

</span>
<br></tr>
<tr>
<span class="com"><t style="position: relative; top: -35px;font-size: 15px;">الملاحظات :</t>
  <textarea  id="filedesc" class="fd" name="filedesc"  placeholder="قم بكتابة ملاحظاتك .....                        ( الحد المسموح 200 حرف فقط )" style=" position: relative; top: 20px; left: -5px; padding: 10px; margin: 10px; border-radius: 10px;  border-style: solid; border-width: thin; background-color: #f0f0f0; " rows="3" cols="30" maxlength="200"></textarea></span>

  <textarea  name="addedon"  id="addedon"  value="<?php date_default_timezone_set('Africa/Cairo'); $addedon = date('d/m/Y, h:i:s A');?>"  readonly="" style="background-color: #D8D7D7; color: black; border: none; " rows="1" cols="25" hidden/><?php echo $addedon; ?></textarea>
</tr>
<input type="submit" name="submit" id="submit" value="رفع الملف" class="btnup">
</div>
</form>
</tr>

  </table>
<!--
<button class="btnup" type="submit">Upload</button>
-->

</div>
<br>
<hr size="2" color="gray" width="20%" class="lines2" style="float: right;">

</html>
<?php 

include 'uploadscript.php';
//include 'connect.php';

 ?>

<style type="text/css">
  td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
  
  $(document).ready(function(){
  $("tr").on({
    mouseenter: function(){
      $(this).css("background-color", "F5CECE");
    },  
    mouseleave: function(){
      $(this).css("background-color", "");

    }  
  });
  
  
  
  $("tr:nth-child(even)").on({
    mouseenter: function(){
      $(this).css("background-color", "898181");
    },  
    mouseleave: function(){
      $(this).css("background-color", "CECACA");

    }  
  });
});

</script>


 <?php
  
$r = mysqli_query($conn , "SELECT * FROM hruploadedfilesa");




$count = mysqli_num_rows($r);
if ($count<1) {
    # code...
    echo "<p style='font-size: 30px; text-align:center;='>لا يوجد ملفات تم ارفاقها</p>";
}
else{
          
echo "




<table  id=\"myTable\" style=\"width:99.9%; font-size: 15px;\">
  <tr>
    <th style='background-color :#2E2D2D; color:white;'>رقم المعرف</th>

    <th style=\"background-color :#2E2D2D; color:white;\"> اسم الملف</th>

    <th style=\"background-color :#2E2D2D; color:white;\">الملاحظات</th>

    <th style=\"background-color :#2E2D2D; color:white;\">الملف</th>


    <th style=\"background-color :#2E2D2D; color:white;\">وقت التعديل</th>
    
  </tr>



";
            

 
       
///////////////https://www.youtube.com/watch?v=BSW6Q_wW_yk///   Mar de la Tranquilidad  /////
  //if(isset($_POST['check'])){
    while ($row = mysqli_fetch_array($r)){


      echo "<tr>";



      echo "<td><div style=\"position: absolute;\">$row[id]</div><a href='view2.php?id=$row[id]' class=\"fa fa-search\" style=\"margin:2px;\" title='View'></a><a href='edit2.php?id=$row[id]' class=\"fa fa-edit\" style=\"margin:2px;\" title='Edit'></a></td>";
        echo "<td>$row[titleF]</td>";
      echo "<td>$row[descF]</td>";
      
      echo "<td>$row[fileFullNameF]</td>";
      
      echo "<td>$row[date]</td>";
        //echo "<td>$row[ip]</td>";
      


      echo "</tr>";


    }

 }

//}
  ?>



</div>
 
<div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <n  target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></n>*</p>

</details>
</div>