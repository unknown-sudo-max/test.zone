
<?php


require_once 'connect.php';
//require_once 'Add_new_user.php';

if(isset($_POST['addneweo'])){



//@$alert =$_POST['alert'];

 


if (!empty($_POST['patient_name']) && !empty($_POST['unique_id']) && !empty($_POST['medical_number']) && !empty($_POST['gender'])) {

	# code...

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	# code...
@$unique_id                      = strip_tags($_POST['unique_id']);
@$medical_number                 = strip_tags($_POST['medical_number']);
@$patient_name                   = strip_tags($_POST['patient_name']);
@$pa_national_id                 = strip_tags($_POST['pa_national_id']);
@$pa_phone_num                   = strip_tags($_POST['pa_phone_num']);
@$spo_phone_num                  = strip_tags($_POST['spo_phone_num']);
@$spo_degree_of_kinship          = strip_tags($_POST['spo_degree_of_kinship']);
@$gender                         = strip_tags($_POST['gender']);
@$date_of_birth                  = strip_tags($_POST['date_of_birth']);
@$doctor                         = strip_tags($_POST['doctor']);
@$date_of_entry                  = strip_tags($_POST['date_of_entry']);
@$specialization                 = strip_tags($_POST['specialization']);
@$entry_type                     = strip_tags($_POST['entry_type']);
@$acceptance_permission	         = strip_tags($_POST['acceptance_permission']);
@$section                        = strip_tags($_POST['section']);
@$financial_transaction          = strip_tags($_POST['financial_transaction']);
@$room                           = strip_tags($_POST['room']);
@$sponsor_name                   = strip_tags($_POST['sponsor_name']);
@$grade                          = strip_tags($_POST['grade']);
@$health_insurance_beneficiary   = strip_tags($_POST['health_insurance_beneficiary']);
@$sample_result                  = strip_tags($_POST['sample_result']);
@$scan_facility_code             = strip_tags($_POST['scan_facility_code']);
@$referred_center                = strip_tags($_POST['referred_center']);
@$added_by                       = strip_tags($_POST['added_by']);
@$last_edit_by                   = strip_tags($_POST['last_edit_by']);
@$added_on                       = strip_tags($_POST['added_on']);
@$record_status                  = strip_tags($_POST['record_status']);
@$exit_type                      = strip_tags($_POST['exit_type']);



// $query1 = "SELECT * FROM patient_login_eo WHERE medical_number='$medical_number' ";
// $result = mysqli_query($conn, $query1 );
// $count = mysqli_num_rows($result);
// if ($count >0) {}else{
// 				echo "<p style='color:red; font-size:15px;'>Already exist !!!)</p>";
// }


 
$db2  = "INSERT INTO  patient_eo_logs (unique_id,medical_number,pa_national_id,pa_phone_num,patient_name,gender,date_of_birth,doctor,date_of_entry,specialization,entry_type,acceptance_permission,section,financial_transaction,room,sponsor_name,spo_phone_num,spo_degree_of_kinship,grade,health_insurance_beneficiary,sample_result,scan_facility_code,referred_center,record_status,added_by,added_on)VALUES('$unique_id','$medical_number','$pa_national_id','$pa_phone_num','$patient_name','$gender','$date_of_birth','$doctor','$date_of_entry','$specialization','$entry_type','$acceptance_permission','$section','$financial_transaction','$room','$sponsor_name','$spo_phone_num','$spo_degree_of_kinship','$grade','$health_insurance_beneficiary','$sample_result','$scan_facility_code','$referred_center','$record_status','$added_by','$added_on')";



if (mysqli_query($conn, $db2)) {

	# code...

	echo "<p style='color:green; font-size:15px;' hidden>The Record Added Successfully</p>";
}
	else{

		echo "<p style='color:red; font-size:15px;' hidden>Failed TO Add The Record !!!)</p>";
	}


	
//mysqli_close($conn);
}


}else{
	echo "<p style='color:red; font-size:15px;' hidden>The  <u style='font-weight:  bold;'>patient_name & medical_number & gender & date_of_birth </u>   Fields Are Required !!! </p>";
}
/*
if (mysqli_query($conn, $db )) {

	# code...

	echo "user added success";
}
	else{

		echo "failed";
	}

mysqli_close($conn);

*/



}

ob_start();

@session_start();
//@$_SESSION['theuser'] = $_POST['theuser'];

//@$_SESSION['thepass'] = $_POST['thepass'];

//@$_SESSION['thefname'] = $_POST['thefname'];

/*


if(isset($_POST['save'])){

extract($_REQUEST);
$file=fopen('myusers2.php' , 'a');
fwrite(@$file, "///////////////");
fwrite(@$file, $thefname);
fwrite(@$file, " User");
fwrite(@$file, "//");
fwrite(@$file, "\n");
fwrite(@$file, "if(isset($");
fwrite(@$file, "_");
fwrite(@$file, "POST['submit'])){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "user ");
fwrite(@$file, "== '");
fwrite(@$file, $theuser);
fwrite(@$file, "'){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "pass ");
fwrite(@$file, "== '");
fwrite(@$file, $thepass);
fwrite(@$file, "'){");
fwrite(@$file, "echo ");
fwrite(@$file, "\"<script>");
fwrite(@$file, "window.location.href=");
fwrite(@$file, "('Avaya_vaildation.php');");
fwrite(@$file, "</script>\";");
fwrite(@$file, "}");

fwrite(@$file, "else{");

fwrite(@$file, "$");
fwrite(@$file, "error ");
fwrite(@$file, "= ");
fwrite(@$file, "\"<div ");
fwrite(@$file, "style='position: relative;text-align: center;'>");
fwrite(@$file, "<n style='color: red;'>");
fwrite(@$file, "Invalid Login</n>");
fwrite(@$file, "<br><k>");
fwrite(@$file, "Check your password again , OR refer to your Adminstrator");
fwrite(@$file, "</k><div>\";");
//fwrite(@$file, "$error = \'<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Login</n><br><k>Check your password again , OR refer to your Adminstrator</k><div>\';");
   
fwrite(@$file, "$");
fwrite(@$file, "success ");
   fwrite(@$file, "= '';"); 


     fwrite(@$file, "echo \"<br><br> <br> ");    
     fwrite(@$file, "$");
     fwrite(@$file, "error\";");       
     fwrite(@$file, "}}}");  
     fwrite(@$file, "\n");       

            
}

*/





  ob_end_flush();

?>
