	<?php 
include 'connect.php';?>
<!DOCTYPE html>
<html  dir="rtl" lang="ar">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<style type="text/css">
	

	.container{
		width: 50%;
		height: 50%;
		background-color: gray;
		position: absolute;

		 
        
        text-align: left;

transform: translate(-50%, 0%);


}

.spanid{
	position: relative;
	padding: 13px;
	margin:  9px;
	top: 30%;

	color: whitesmoke;
}

.inputid{
	position: relative;
	width: 10%;
	background: rgba(255, 255, 255, 0);
    border-radius: 1px;
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(0px);
    -webkit-backdrop-filter: blur(0px);
	top: 30%;
	border: none;
	font-family: cursive;
	font-size: 20px;

	color: whitesmoke;
}

.container2{


	height: 20%;
	background-color: black;
	
	}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 15px;
  margin: 20px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.spannos{

	right: 350%;
	position: relative;
}

li{
	list-style-type: none;

}
a:hover {
  background-color: #ddd;
  color: black;
}

a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.container4{
	background-color: black;
	position: relative;
	top: 10px;
	color: whitesmoke;
	
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){

window.scrollTo(0,0);
});
</script>
<body>
	<form  method="get" enctype="multipart/form-data">
	<div class="container">
		<div class="container2">
<span>
	<input type="text" name="id" class="inputid" maxlength="5" value="<?php $id =$_GET['id']; echo $id; ?>" readonly="">

<span class="spanid">: Record ID</span>

</span>
			
		</div>

<div class="container3">
	

 

<?php



$id =$_GET['id'];

$query = "SELECT * FROM hruploadedfiles WHERE id='$id' ";
$query_run = mysqli_query($conn, $query);
if (mysqli_num_rows($query_run) > 0) {
    # code...
   foreach ($query_run as $row) {
   	// code...



echo "

	<table>
		<tr>
    <th>اسم الملف :</th>
    <th>الملاحظات :</th>
     
  </tr>
  <tr>
    <td>$row[titleF]</td>
    <td>$row[descF]</td>
     
  </tr>
  <tr>
    <th>الملف :</th>
    <th>التاريخ :</th>
     
  </tr>
  <tr>
    <td>$row[fileFullNameF]</td>
    <td>$row[date]</td>
     
  </tr>
 
	</table>

	<div class=\"container4\">

<span><a class=\"list\" href=\"iframelist.php\"><li>السابق ←</li></a></span>
			
		</div>


	</div>

";

   	 






   }
}
else{
	 echo "<p style='font-size: 30px; text-align:center;='>لا يوجد ملفات تم ارفاقها</p>";
	}










?>





</div>







</form>
</body>
</html>
