

<!DOCTYPE html>
<html>
<head>

	<title></title>
</head>
<style type="text/css">
	
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.header {
  padding: 7px;
  text-align: left;
  background: #C0C0C0;
  color: white;
  font-size: 10px;
}


</style>
<body>
	
<div class="header">

	<?php
  ob_start();
// session_start();

 
session_start();
echo "<p>Welcome</p>" .$_SESSION['user'];
echo "<br><br>";
echo "";
 



if (empty($_SESSION['user'])) {
  # code...
   // echo "<script> window.location.href=('index.php');</script>";
           
  //header("Location: index.php");
 } 
else{
  echo "Administration Area";
}
if ((time() - $_SESSION['last_time']) > 900) {
  # code...
  session_unset();

  // echo "<script> window.location.href=('index.php?session=expired');</script>";
}
 
 ob_end_flush();
?>
</div>





</body>


</html>