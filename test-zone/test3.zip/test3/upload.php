<html>
<body>
<style>
 .button {
    
  display: inline-block;
  border-radius: 4px;
  background-color: #848282;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 17px;
  padding: 10px;
  width: 30%;
  height:50px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 
<form action="upload.php" method="post" enctype="multipart/form-data">
  <?php




$fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($fullurl, "upload=empty") == true) {
  
  echo "<div style='position: relative;
      text-align: center;
    font-weight: bold;
    color: red;
    '> <u >You Can't Leave This Fields Empty !!! </u></div>";
   
  echo "<br>";
}


 
 

$fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($fullurl, "upload=Success") == true) {
  
  echo " <div style='color:green; text-align: center; font-weight: bold; position: relative; ' >Your File Uploaded Successfully</div>";
  echo "<br>";
   
}


 ?>
  
  <input type="file" id="file" name="file" required="">
<i class="fa fa-photo"></i>
<br>
<br>
<table>
<tr>
<th>
<p>Add Title</p>

</th>
<th>
  <input type="hidden" name="filename" placeholder="filename .. ">
  
<input type="text" id="filetitle" name="filetitle" placeholder="Image Title ... " required="" autofocus>
</th>
</tr>
<tr>
<td>
<p>Add Highlight Tag</p>
</td>
<td>
<input type="text" id="filedesc" name="filedesc" placeholder="Image Tag .. ">
</td>
<td>
<textarea  name="addedon"  id="addedon"  value="<?php date_default_timezone_set('Africa/Cairo'); $addedon = date('d/m/Y, h:i:s A');?>"  readonly="" style="background-color: #D8D7D7; color: black; border: none; " rows="1" cols="25" hidden/>
 <?php

echo($addedon);
?>
</textarea>
 

</td>
</tr>
<td></td>
</table>
<br><br><br>
<!--
*/
//<input type="text" name="filename" placeholder="filename .. ">
<input type="text" name="filetitle" placeholder="filetitle .. ">
<input type="text" name="filedesc" placeholder="filedesc .. ">
-->
  <input type="submit" name="submit" id="submit" value="UPLOAD" class="button">
</form>

            
</body>
</html>
<?php
include_once 'connect.php';
$ip = $_SERVER['REMOTE_ADDR'];
//echo "<br><br>Your IP : " . $ip;


 $sql = "SELECT * FROM viewers WHERE ip='$ip';";
 $result = mysqli_query($conn,$sql);
 if (!$result) {
   // code...
  echo "Failed sql";

 }
 $total_vistors = mysqli_num_rows($result);
 if ($total_vistors < 1 ) {
   // code...
  $sql2 = "INSERT INTO viewers (ip) VALUES ('$ip')";
  $result = mysqli_query($conn,$sql2);

 }


 //echo "<br><br>vistors : ". $total_vistors;

$select_user = "SELECT * FROM views WHERE user ";
$query_select = mysqli_query($conn,$select_user);
while ($data=mysqli_fetch_assoc($query_select)) {
  // code...
  echo $data['user'],"<br>";
}



 /*

//////////////////////counting 

 $sql = "SELECT ip FROM viewers ip='$ip';";
 $check = $conn->prepare($sql);
 $check->execute();
 $checkIp=$check->rowCount();
 if ($checkIp == 0) {
   // code...

  $query = "INSERT INTO gallery (user, ip, date,) VALUES (NULL,?,NULL) ";
  $insertIp = $conn->prepare($query);
  $insertIp->execute();

 }

$number = $conn->prepare("SELECT ip FROM gallery");
$number->execute();
$visitor = $number->rowCount();
echo $visitor;

////////////////
*/

include 'uploadscript.php';






/*






$sql='SELECT * from viewers';

$res=mysqli_query($conn,$sql);

$row=mysqli_fetch_array($res);

$str=$row[0];

$length=strlen($str);

if($length==1)
 $counter="00000000".$row[0];
else if($length==2)
 $counter="0000000".$row[0];
else if($length==3)
 $counter="000000".$row[0]; 
else if($length==4)
 $counter="00000".$row[0];
else if($length==5)
 $counter="0000".$row[0];
else if($length==6)
 $counter="000".$row[0];
else if($length==7)
 $counter="00".$row[0];
else if($length==8)
 $counter="0" .$row[0];

$up_count=$row[0]+1; 
$sql="UPDATE `viewers` SET `views`= '$up_count' WHERE -1";

mysqli_query($conn,$sql);
*/

?>

<!--

<div class='row' style='margin-left:10px;margin-top:20px'>
 <div cass='col-4'>
  <h5 class='text-danger'>Total Visits</h5>
 </div>
 <div class='col-8'>
  <table class='text-white bg-info table-sm'> 
   <tr>
      <td style='border:1px solid yellow'><?php echo $counter[0] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[1] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[2] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[3] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[4] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[5] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[6] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[7] ?></td>
      <td style='border:1px solid yellow'><?php echo $counter[8] ?></td>
    </tr>
  </table>
 </div>
</div>
-->