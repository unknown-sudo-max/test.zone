<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
<link href='https://fonts.googleapis.com/css?family=Big Shoulders Inline Text' rel='stylesheet'>
<style>


* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}
@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){

window.scrollTo(0,0);
});
</script>
<!--
<div class="logo">
  </div>
-->

 
<div class="container">

<h4 style="font-family :  'Big Shoulders Inline Text'; font-size: 30px;">Head List</h4>

<ul>
  <a class="list" href="lists/list1.php"><li>List 1</li></a>
   
  <a class="list" href="lists/list2.php"><li>List 2</li></a>
  
  <a class="list" href="lists/list3.php"><li>List 3</li></a>
   
  <a class="list" href="lists/list4.php"><li>List 4</li></a>

      </ul>
      
    
</div>
 
