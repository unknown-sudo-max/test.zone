<!doctype html>
<html   dir="ltr" lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<title>Login</title>


		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-6">
	
               
		
	</head>
	 <link REL="stylesheet" href="login.css" type="text/css">
		

		
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


	<body class="CityOffice page-login function-login" >


	<center>

<h1 style="display: block; font-size: 40px; font-family: 'Brush Script MT', cursive;"><t style="font-family: 'Amita';">HR Public Folder</t><br><t style="font-family: 'Almendra Display';"> Al-Agouza Hospital</t> </h1>
</center>


	 <form method="post"   id="form1" name="form1" >
			



<br>

<br>

<?php


$fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($fullurl, "session=expired") == true) {
	echo "<br>";
	echo "<div style='position: relative;
	    text-align: center;
		font-weight: bold;
		color: red;
		'> <u >Your Session has been Expired</u></div>";
	echo "<br>";
	echo "<br>";
}



?>

 






					<input type="hidden" name="btnSubmit" value="Login">
		
	<div class="rnr-page">
		<div class="rnr-top ">
			

<div  class="rnr-cw-fields rnr-s-fields asbuttons CityOffice">
<div class="rnr-c rnr-cv rnr-c-fields">


<div  class="rnr-brickcontents style2 rnr-b-loginheader "><span>	<h1 style=" font-family: 'Brush Script MT', cursive; font-size: 20px">#_ Login</h1>
</span></div>






<div  class="rnr-brickcontents style1 rnr-b-loginfields "><table class="fieldGrid">
	<tr>
		<td>
			Username:
		</td>
		<td class="rnr-control">
			<input type="text" name="user" id="user" value="">
		</td>
	</tr>
	<tr>
		<td>
			Password:
		</td>
		<td class="rnr-control">
			<input type="password" name="pass"  id="pass" value="">
		</td>
	</tr>
					<tr>
		<td>
			Remember Password:
		</td>
		<td>
			<input type="checkbox" name="remember_password" value="1">
		</td>
	</tr>
	
     </table>					</div>






<tr>

	<div  class="rnr-brickcontents style2 rnr-b-loginbuttons ">

<td>


	<button  class="rnr-button main" name="submit" id="submitLogin1">Login</button>


</td>
 <td>  
   
   <a href="mailto:misho3333misho@gmail.com?Subject=I Need to Sign Up to Login Avaya Deadline - User : ('Add your user her ')&amp;body=I Need to Sign Up to Login Avaya Deadline  %0D%0D Name :                 %0D Phone number :                    %0D Mail :                    %0D User :         . %0D%0D%0D%0D%0D%0D ,Best Regards%0D%0D" style="font: 13px Segoe UI; font-weight: bold; text-align: left; position: absolute; left: 57%;" id="send" name="send">Send A Sign up Request</a>


     


     


      </td>


     </div> 

     </tr>


		

</div>
</div>


		</div>
		<div class="rnr-middle">
			<div class="rnr-left ">
				
			</div>
			<div class="rnr-center ">
				
			</div>
			<div class="rnr-right ">
				
			</div>
		</div>
		<div class="rnr-bottom ">
			<!--%%bottom%%-->
		</div>
	</div>
		
		<SCRIPT>
$(document).ready(function(){

	$(document).on("change","input[type='text'],textarea,input[type='number']",function(){
	
		var inputVal = $(this).val().trim();
		
		inputVal = htmlEntities(inputVal);
		inputVal = mysqlEscape(inputVal);
		
		$(this).val(inputVal);
		
	});

});

function mysqlEscape(stringToEscape){
    return stringToEscape
        .replace("\\", "\\\\")
        .replace("\'", "\\\'")
        .replace("\"", "\\\"")
        .replace("\x00", "\\\x00")
        .replace("\x1a", "\\\x1a");
}

function htmlEntities(str) {
    return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

</SCRIPT><SCRIPT>
$(document).ready(function(){

$("#simpleSrchFieldsCombo1").find("option:contains('Any field')").remove()
$("#simpleSrchTypeCombo1").find("option:contains('Equals')").prop('selected',true)
});
</SCRIPT><SCRIPT>

$(document).ready(function(){
	
	var IRPageURL=window.location.href.toLowerCase().trim();
	
	if(IRPageURL.indexOf("_add.php")>-1 || IRPageURL.indexOf("_edit.php")>-1)
		$("input[type='text'],select").css("width","207px")
});
</SCRIPT>






	</form><script > 








	</script>



 <?php





require_once('connect.php');
include 'user validation.php';

  
 


//header('location: index.php');


//setcookie('user' , $_POST['user'] , time() +86409999999990 );

//setcookie('user' , @$_POST['user'], time() + (86400 * 30), "/"); // 86400 = 1 day


if(isset($_POST['submit'])){

  
 $_SESSION['last_time'] = time();

	//$user = $_SESSION['user'];
	//echo "$user<br><br>";
}


date_default_timezone_set('Africa/Cairo');
$dt = date('d/m/Y, h:i:s A');






echo("<n style='font-family: Courier New, monospace;'>  $dt</n>");



echo("<br>");
echo("<br>");
$today = date('w');
 
switch ($today) {
	case 1:
          echo "<div style= 'position: relative; text-align: center;  '><b>اليوم : الأثنين <mark>:) </mark> </b></div>";
          break;
    case 2:
          echo "<div style= 'position: relative; text-align: center;  '><b>اليوم : الثلاثاء <mark>:| </mark></b></div>";
          break;
    
    case 3:
          echo "<div style= 'position: relative; text-align: center;  '><b>اليوم : الأربعاء <mark><b>:( </mark></b></div>";
          break;

    case 4:
          echo "<div style= 'position: relative; text-align: center;  '><b>اليوم : الخميس<mark> :\ </mark></b></div>";
          break;
    case 5:
          echo "<div style= 'position: relative; text-align: center;  '><b><u>اليوم : الجمعة </u><mark>  ;)</mark> </b></div>";
          break;
    case 6:
          echo "<div style= 'position: relative; text-align: center;  '><b>اليوم : السبت <mark>:o </mark></b></div>";
          break;
    case 0:
          echo "<div style= 'position: relative; text-align: center;  '><b>اليوم : الأحد<mark> :/ </mark></b></div>";
          break;                                    

}
echo("<br>");
echo("<br>");
 


 ?>

 <center>
 	<div>
<img src="pngeggg.png" class="logo"  >
<br>


</div>
 <div class="cpr"  >

 	<span ><u style="color:gray;">جميع الحقوق محفوظة © 2022-2023</u></span>
 </div>
 </center>

		
	</body>
	<link REL="stylesheet" href="https://fonts.googleapis.com/css?family=Acme"   type="text/css">
		<link REL="stylesheet" href="https://fonts.googleapis.com/css?family=Amita"   type="text/css">
		<link REL="stylesheet"  href="https://fonts.googleapis.com/css?family=Almendra Display"  type="text/css">
		<style type="text/css">
			.logo{
				width: 10%; 
				position: relative; 
				float: center;
			  opacity: 0.9;
			}
		</style>
	 
</html>
