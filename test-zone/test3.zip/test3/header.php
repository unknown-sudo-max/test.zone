<?php 


// access('VIEWER');

?>

<!DOCTYPE html>
<html lang="en" dir="rtl" >
<head>
<title>Al-Agouza_Public_Folder</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="M_G_X_Test3" />
 <link rel="icon" type="image/png" href="./img/rrrrr.png">
<link rel="stylesheet" href="test2.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<link rel="stylesheet"  type="text/css" href="print.css" media="Print">

<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

 
</script>

<style>
 @import url('https://fonts.googleapis.com/css2?family=Alexandria&family=Amatic+SC&family=Carattere&family=Cormorant+SC&family=Cormorant+Upright&family=Crimson+Text&family=Major+Mono+Display&family=Nabla&family=Reem+Kufi&family=Reem+Kufi+Ink&family=Road+Rage&display=swap');
@import url(//db.onlinewebfonts.com/c/97c4b25dc74e0ab045154e75a8fdd69d?family=Game+of+Thrones);


/*font-family: 'Alexandria', sans-serif;
font-family: 'Amatic SC', cursive;
font-family: 'Carattere', cursive;
font-family: 'Cormorant SC', serif;
font-family: 'Cormorant Upright', serif;
font-family: 'Crimson Text', serif;
font-family: 'Major Mono Display', monospace;
font-family: 'Nabla', cursive;
font-family: 'Reem Kufi', sans-serif;
font-family: 'Reem Kufi Ink', sans-serif;
font-family: 'Road Rage', cursive;*/




body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size:16px;}
.w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.w3-half img:hover{opacity:1}
.wc{
 position: relative;
    float: left;
   left: 0;
   height: 5%;
}

.sessiondiv{

  position: relative;
  width: 10%;
  font-size: 10px;
  left: 0;
  top: -100px;

}

.logoutbtn{

      color: #fff!important;
    background-color: #48153c;
    border: none;
    outline: none;
    cursor: pointer;
    width: 100%;
    padding: 10px;
    margin: 2px;
    text-align: right;
    /**/


}

.logoutbtn:hover{

      color:black!important;
    background-color: white!important;


}


</style>
</head>
<?php  
//include_once 'headerra.php';

?>
<body>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-red w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Close Menu</a>
  <div class="w3-container">
   
    <h3 class="w3-padding-64"><b style="font-family: 'Major Mono Display', monospace; cursor:pointer;" onclick="window.location.href=('main_test2.php');">Al-Agouza<br>Hospital</b></h3>
  </div>
  <div class="wc">

  <?php
  // ob_start();
// session_start();

 
@session_start();

echo "<br>";
echo "<span class='sessiondiv' style=\"font-family: 'Major Mono Display', monospace;\"><p>Hello: $_SESSION[user] <t style='color: gray;'>_($_SESSION[type])<t></p></span>";
echo "<br><br>";
echo "";
 



if (empty($_SESSION['user'])) {
  # code...
   echo "<script> window.location.href=('index.php');</script>";
   die();
           
  //header("Location: index.php");
 } 
else{
  // echo "Administration Area";
}
// if ((time() - $_SESSION['last_time']) > 10 && $_SESSION['type'] = 'admin') {
//   # code...
//   session_unset();

//   echo "<script> window.location.href=('index.php?session=expired');</script>";
//   die();
// }
 

 if (($_SESSION['type'] === 'admin' && (time() - $_SESSION['last_time']) === 10)) {
  # code...
  // session_unset();
   echo "<script>alert('Dont Worry,  you are admin there\'s no expiration for you. 😉');</script>";


  // echo "<script> window.location.href=('index.php?session=expired');</script>";
  // die();
} else if (($_SESSION['type'] === 'eo_user' || $_SESSION['type'] === 'hr_user' || $_SESSION['type'] === 'acc_user' || $_SESSION['type'] === 'hr_viewer' || $_SESSION['type'] === 'eo_viewer') && (time() - $_SESSION['last_time']) > 10) {
  session_unset();

  echo "<script> window.location.href=('index.php?session=expired');</script>";
  die();
}





 ob_end_flush();


 if(isset($_POST['submitLogin1'])){

         
    session_unset();


           echo "<script> window.location.href=('index.php');</script>";
           die();
           
            //header("Location: index.php");

  # code...
  
}

//////////////////////////main////////////////////

 if(isset($_POST['main'])){

         
  


           echo "<script> window.location.href=('../test3/main_test2.php');</script>";
           
            //header("Location: index.php");

  # code...
  
}

///////////////hr///////////////////////

if(isset($_POST['hr'])){

         
  


           echo "<script> window.location.href=('../test3/hr_test2.php');</script>";
           
        
  
}

////////////////////eo////////////////////

if(isset($_POST['eo'])){

         
  


           echo "<script> window.location.href=('../test3/eo_test2.php');</script>";
           
        
  
}

//////////////////acc////////////////////


if(isset($_POST['acc'])){

         
  


           echo "<script> window.location.href=('../test3/acc_test2.php');</script>";
           
        
  
}


//////////////////help////////////////////


if(isset($_POST['help'])){

         
  


           echo "<script> window.location.href=('../test3/help_test2.php');</script>";
           
        
  
}

?>
<style type="text/css">
  .logomain{

  width: 80%;
  position: absolute; 
  right: -80px; 
  top: -259px;
  cursor: pointer;

}

@media screen (max-width: 580px) {

}
@media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){

}
@media screen and (min-width: 790px) and (min-height: 640px) and (max-width: 1150px) and (max-height: 1200px){

  .logoph{
         width: 10%; 
         position: absolute; 
         left: 0; 
         top: -10%; 
         z-index: -1;

}

.logomain{

  width: 60%;
  position: absolute; 
  right: -80px;
  top: -224px;
  z-index: -1;
  cursor: pointer;

}

}
@media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1200px){

.logoph{
    width: 15%;
    position: absolute;
    left: 0;
    top: -0;
    z-index: -1;

}

.logomain{

  width: 60%;
  position: absolute; 
  right: -80px;
  top: -224px;
  z-index: -1;
  cursor: pointer;

}

}
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){


  .logoph{

    width: 15%;
    position: absolute;
    left: 0;
    top: -3%;
    z-index: -1;

}

.logomain{

  width: 60%;
  position: absolute; 
  right: -80px;
  top: -226px;
  z-index: -1;
  cursor: pointer;

}

}
</style>


 

 <img src="img/rrrrr.png" class="logomain"  onclick="window.location.href=('main_test2.php');">

  </div>


  <br>

  <div class="w3-bar-block" style="font-family: 'Reem Kufi', sans-serif; font-size: 17px; font-weight: normal;">
  <!--   <a href="#" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">الرئيسية</a> 
    
    <a href="#showcase" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Showcase</a> 
    <a href="#services" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Services</a> 
    <a href="#designers" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Designers</a> 
  
    <a href="#packages" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">مساعدة</a> 
 -->
   <!--  <a onclick="history.back()"  name='logout' style="cursor: pointer;" class="w3-bar-item w3-button w3-hover-white">خروج</a> -->
    <form method="post">

    <button  class="logoutbtn" name="main" id="main">الرئيسية</button>
 
    <?php
  require_once  'access.php';
      if (access('HR_VIEWER'  , false)): ?> 
    <button  class="logoutbtn"  name="hr"  id="hr">الموارد البشرية</button>
    <?php endif;?>

    <?php
      if (access('EO_VIEWER' , false)): ?> 
    <button  class="logoutbtn"  name="eo"  id="eo">مكتب الدخول</button>
    <?php endif; ?>

    <?php
      if (access('ACC_VIEWER' , false)): ?> 
    <button  class="logoutbtn"  name="acc" id="acc" >الحسابات</button>
    <?php endif; ?>
    <button  class="logoutbtn"  name="help" id="help" >مساعدة</button>
   <button  class="logoutbtn" name="submitLogin1" id="submitLogin1">خروج</button>
   </form>
  </div>


<!--   /////////////////////////cpr/////////////////////// -->
  <div class="cpr" style="font-family: 'Reem Kufi', sans-serif; font-size: 13px; display: grid;justify-items: center; ">

<details >
<summary style="scale:120px right; ">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p style="display: grid;justify-items: center;"> Powered BY <a target="_top" onclick="window.open('https://unknown-sudo-max.github.io/test.zone/onecode/');" style="color: gray; cursor: pointer;"><u>1-Code</u></a><p style="display: grid;justify-items: center;">M_G_X_CEO&Founder</p></p>

</details>
</div>
<!--   /////////////////////////cpr/////////////////////// -->
</nav>



<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding" id="headerr">
  <img src="img/rrrrr.png" class="logoph"  >
  <a href="javascript:void(0)" class="w3-button w3-red w3-margin-right" onclick="w3_open()" id="w3_open">☰</a>
  <span>Al-Agouza Hospital</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:340px;margin-right:40px">
 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>

<?php  





if (@$_SESSION['type']=='admin' ) {

  echo "<script>document.getElementById('main').style.backgroundColor = '#081a36';</script>";
   echo "<script>document.getElementById('hr').style.backgroundColor = '#081a36';</script>";
    echo "<script>document.getElementById('eo').style.backgroundColor = '#081a36';</script>";
     echo "<script>document.getElementById('acc').style.backgroundColor = '#081a36';</script>";
      echo "<script>document.getElementById('help').style.backgroundColor = '#081a36';</script>";
       echo "<script>document.getElementById('submitLogin1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('id').style.backgroundColor = '#081a36';</script>";
 echo "<script>document.getElementById('mySidebar').style.backgroundColor = '#081a36';</script>";
 echo "<script>document.getElementById('headerr').style.backgroundColor = '#081a36';</script>";
 echo "<script>document.getElementById('w3_open').style.backgroundColor = '#081a36';</script>";





	}elseif (@$_SESSION['type']=='eo_user') {

		 echo "<script>document.getElementById('main').style.backgroundColor = '#1c2827';</script>";
   echo "<script>document.getElementById('hr').style.backgroundColor = '#1c2827';</script>";
    echo "<script>document.getElementById('eo').style.backgroundColor = '#1c2827';</script>";
     echo "<script>document.getElementById('acc').style.backgroundColor = '#1c2827';</script>";
      echo "<script>document.getElementById('help').style.backgroundColor = '#1c2827';</script>";
       echo "<script>document.getElementById('submitLogin1').style.backgroundColor = '#1c2827';</script>";
       echo "<script>document.getElementById('neww').style.backgroundColor = '#1c2827';</script>";
 echo "<script>document.getElementById('mySidebar').style.backgroundColor = '#1c2827';</script>";
  echo "<script>document.getElementById('headerr').style.backgroundColor = '#1c2827';</script>";
   echo "<script>document.getElementById('w3_open').style.backgroundColor = '#1c2827';</script>";


		 
	}elseif (@$_SESSION['type']=='hr_user') {

		  echo "<script>document.getElementById('main').style.backgroundColor = '#000000';</script>";
   echo "<script>document.getElementById('hr').style.backgroundColor = '#000000';</script>";
    echo "<script>document.getElementById('eo').style.backgroundColor = '#000000';</script>";
     echo "<script>document.getElementById('acc').style.backgroundColor = '#000000';</script>";
      echo "<script>document.getElementById('help').style.backgroundColor = '#000000';</script>";
       echo "<script>document.getElementById('submitLogin1').style.backgroundColor = '#000000';</script>";
 echo "<script>document.getElementById('mySidebar').style.backgroundColor = '#000000';</script>";
  echo "<script>document.getElementById('headerr').style.backgroundColor = '#000000';</script>";
   echo "<script>document.getElementById('w3_open').style.backgroundColor = '#000000';</script>";


		 
	}elseif (@$_SESSION['type']=='acc_user') {

		 echo "<script>document.getElementById('main').style.backgroundColor = '#483131';</script>";
   echo "<script>document.getElementById('hr').style.backgroundColor = '#483131';</script>";
    echo "<script>document.getElementById('eo').style.backgroundColor = '#483131';</script>";
     echo "<script>document.getElementById('acc').style.backgroundColor = '#483131';</script>";
      echo "<script>document.getElementById('help').style.backgroundColor = '#483131';</script>";
       echo "<script>document.getElementById('submitLogin1').style.backgroundColor = '#483131';</script>";
 echo "<script>document.getElementById('mySidebar').style.backgroundColor = '#483131';</script>";
  echo "<script>document.getElementById('headerr').style.backgroundColor = '#483131';</script>";
   echo "<script>document.getElementById('w3_open').style.backgroundColor = '#483131';</script>";


		 
	}else{
            echo "<script>function(){ history.back(); }</script>";
	}





?>