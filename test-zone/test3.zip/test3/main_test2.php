
  <!-- Header -->
<?php 

require_once('header.php');


?>
<!-- End page content -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });



// function realtimeclock() {

//   var rtclock = new Date();

//   var hours   = rtclock.getHours();
//   var minutes   = rtclock.getMinutes();
//   var seconds   = rtclock.getSeconds();

//   var ampm  = (hours < 12) ? "AM" : "PM";
//   hours =  (hours < 12) ? hours - 12 : hours;

//   hours = ("0" + hours).slice(-1);
//   minutes = ("0" + minutes).slice(-2);
//   seconds = ("0" + seconds).slice(-2);

//   document.getElementById('clock').innerHTML = hours + " : " + minutes + " : " + seconds +" "+ ampm;
// var t = setTimeout(realtimeclock, 500);

// }

// function display_c(){
// var refresh=1000; // Refresh rate in milli seconds
// mytime=setTimeout('display_ct()',refresh)
// }

// function display_ct() {
// var x = new Date()
// document.getElementById('ct').innerHTML = x1;
// display_c();
//  }


function display_ct5() {
var x = new Date()
var ampm = x.getHours( ) >= 12 ? ' PM' : ' AM';

var x1=x.getMonth() + 1+ "/" + x.getDate() + "/" + x.getFullYear(); 
x1 = x1 + " - " +  x.getHours( )+ ":" +  x.getMinutes() + ":" +  x.getSeconds() + ":" + ampm;
document.getElementById('ct5').innerHTML = x1;
display_c5();
 }
 function display_c5(){
var refresh=1000; // Refresh rate in milli seconds
mytime=setTimeout('display_ct5()',refresh)
}
display_c5()



</script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Alexandria&family=Amatic+SC&family=Carattere&family=Cormorant+SC&family=Cormorant+Upright&family=Crimson+Text&family=Major+Mono+Display&family=Nabla&family=Reem+Kufi&family=Reem+Kufi+Ink&family=Road+Rage&display=swap');
/*font-family: "Game of Thrones";*/

* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

/*.cpr{

  padding: 12px;
  margin: 12px;
  position: absolute;

  text-align: center;
 cursor: not-allowed;
  top: 84%;
  left: 30%;
  
}*/


.cpr{

 
  text-align: center;
 cursor: not-allowed;
  
  
}
 
details > summary {
  list-style: none;
}

.coninsmsg .insmsg{
    direction: rtl;
    text-align: right;
}


.bkga{

     z-index: -1;
     width: 90%; 
     position: fixed; 
     background-size: cover; 
     opacity: 0.5; 
     left: -120px; 
     top: -196px;
}


@media screen (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }

  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }

  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}

}



 @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){
.container{
  
  position: absolute;
  top: 0;



}
 
 .w3-xlarge {
    font-size: 22px!important;
}


  }


   @media screen and (min-width: 790px) and (min-height: 640px) and (max-width: 1150px) and (max-height: 1200px){
.container{
  
  position: absolute;
  top: 0;



}
 
 .w3-xlarge {
    font-size: 22px!important;
}


.coninsmsg .insmsg{
 width: 90%;
    position: absolute;
    left: 4%;
    right: 0;
    display: flex;
    justify-content: center;
    justify-items: center;
}



.bkga{

     z-index: -1;
     width: 100%; 
     position: fixed; 
     background-size: cover; 
     opacity: 0.8; 
     left: -185px;
     top: -76px;
}

  }
 
 
 

 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1200px){
.container{
  
  position: absolute;
  top: 65px;



}

.coninsmsg .insmsg{
   width: 128%;
   position: absolute;
   left: 4%;
   right: 0;
   display: flex;

   justify-content: center;
    justify-items: center;
}

.bkga{

     z-index: -1;
     width: 100%; 
     position: fixed; 
     background-size: cover; 
     opacity: 0.8; 
     left: -29px;
     top: 29px;
}
 
 }
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

 

.container{
  
  position: absolute;
  top: 90px;



}
 
 .w3-xlarge {
    font-size: 22px!important;
}


.cpr{

  display: flex;
  align-items: center;
  position: absolute;
  left: 17%;
  justify-content: center;
  justify-items: center;
 
}

.coninsmsg .insmsg{
   width: 128%;
   position: absolute;
   left: 4%;
   right: 0;
   display: flex;

   justify-content: center;
    justify-items: center;
}


.bkga{

     z-index: -1;
     width: 100%; 
     position: fixed; 
     background-size: cover; 
     opacity: 0.8; 
     left: -29px;
     top: 158px;
}

}
</style>


<body onload=display_ct(); >
<div class="container" style="float: left" dir="ltr">

<h4 style="font-family: 'Carattere', cursive; font-size: 30px;">Main-_-List</h4>


<!-- <ul>
  <a class="list" href="hr_list1.php"><li>List 1 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </li></a>
   <hr  class="lines2" >
  <a class="list" href="hr_list2.php"><li>List 2  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
     <hr  class="lines2" >
  <a class="list" href="hr_list3.php"><li>List 3   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
     <hr  class="lines2" >
  <a class="list" href="hr_list4.php"><li>List 4   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>

      </ul>
       -->

       <img src="img/rrrrr.png" class="bkga" >

       
    
<div><span><h3 style="font-family: 'Major Mono Display', monospace;">Al-Agouza Hospital</h3><sub style="font-family: 'Reem Kufi Ink', sans-serif;">Date: <span id='ct5' ></span></sub>   </span> </div>

<div style="width: 103%;">
  <hr >

<marquee  behavior="scroll" width="130%" direction="right" height="100px" scrollamount="15" style="font-family: 'Reem Kufi', sans-serif;background-color: #89898996; padding: 10px; height: 40px; margin: 2px;opacity: 0.9; text-shadow: 0 0 3px #d1d1d1, 0 0 5px #ffffff color: black;">
  
مستشفى العجوزة : &nbsp; تاسست عام (1877) , ملاحظات ادارية :   &nbsp; &nbsp;  تعلن ادارة المستشفي عن اعلان رحلة للموظفين لحديقة الحيوان في يوم (1-1-2050) و بالاضافة ان قيمة الاشتراك (1000) جنية لكل من يهمه الامر الرجاء المبادرة بسرعة الحجز
</marquee>
<hr  >
<div class="coninsmsg">
<fieldset class="insmsg">
 <legend>  <span style="font-family: 'Reem Kufi Ink', sans-serif; font-weight: bold; font-size: 220%;" dir="rtl">الرؤية والرسالة :</span> </legend>


<dl>

<dt style="font-weight: bold; padding:2px; margin: 4px; font-family: 'Reem Kufi Ink', sans-serif;">رؤيتنـــا</dt>

<dd style="font-family: 'Reem Kufi', sans-serif;">أن نكون من أفضل مقدمي الخدمات الصحية بالمنطقة وفق أعلى معايير الجودة والاعتماد.</dd>

<dt  style="font-weight: bold; padding:2px; margin: 4px; font-family: 'Reem Kufi Ink', sans-serif;">رسالتنـا</dt>
<dd style="font-family: 'Reem Kufi', sans-serif;">تقديم خدمات صحية آمنة عالية الجودة تفوق توقعات عملائنا من خلال فريق طبي متكامل ومتميز, باستخدام أحدث الأجهزة والتقنيات الطبية المتطورة مع التزامنا بالمهنية العالية والتعليم والتطوير المستمر.</dd>

<hr>
<dt style="font-weight: bold; padding:2px; margin: 4px; font-family: 'Reem Kufi Ink', sans-serif;">قيمنا وأعرافنا الأساسية</dt>
<dd style="font-family: 'Reem Kufi', sans-serif;">
<ol>

<li><u style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">المريض أولا :</u><t style="font-family: 'Reem Kufi', sans-serif;">المرضى في مقدمة أولوياتنا, إن أفضل مقياس لنجاحنا هو درجة الرضى للمراجعين عن خدماتنا.</t></li>
<li><u style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">التميـــــــــز :</u><t style="font-family: 'Reem Kufi', sans-serif;">نحن نسعى إلى تقديم أفضل الخدمات الطبية من خلال فريق طبي متكامل و متميز.</t></li>
<li><u style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">الاحتــــــرام :</u><t style="font-family: 'Reem Kufi', sans-serif;">يعتبر موظفونا من أولى اهتماماتنا, فنحن نقدر و نطور مساهمات كل واحد منهم في ظل تعدد الخبرات والثقافات والقدرات التي يتشكل منها طاقم المستشفى.</t></li>
<li><u style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">الشـــــراكة :</u><t style="font-family: 'Reem Kufi', sans-serif;">يعتبر التعاون و التنسيق مع مقدمي الخدمات الصحية المحليين و الدوليين في غاية الأهمية, فنحن نشجع تبادل الخبرات والدعم المهني والمنافسة الايجابية.</t></li>
<li><u style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">العمل الجماعي:</u><t style="font-family: 'Reem Kufi', sans-serif;">إن توفر جو من الدعم والانفتاح وسعة الأفق يشجع على الإبداع والابتكار وتحسين الجودة في العمل الفردي والجماعي.</t></li>
<li><u style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">المهنيــــــة :</u><t style="font-family: 'Reem Kufi', sans-serif;">نحن نثق في قدرات وكفاءات ومهارات فريق العمل لدينا ونؤمن بأنهم قادرون على أداء واجبهم بكل عناية وحرص ودقّة.</t></li>




</ol>  
</dd>
<dt><t style="font-weight: bold; padding:2px; margin: 4px;font-family: 'Reem Kufi', sans-serif;">أنتم في أعيننا: </t><t style="font-family: 'Reem Kufi', sans-serif;">تصف هذه الكلمات البسيطة الماضي والحاضر والمستقبل لمستشفى العجوزة، وتمتد جذورنا عميقاً في المجتمع كما أن إستثمارنا في المواهب والخدمات يفيد المجتمع قاطبة. ليست الحياة هي ما نفعله من أجل أنفسنا بل ما نفعله من أجل للآخرين.</t></dt>


</dl>






<!-- <div>
• ضمان جودة الخدمات الصحية والتحسين المستمر لها وتوكيد الثقة في جودة مخرجات الخدمات الصحية لجمهورية مصر العربية على كافة مستويات المنشآت الصحية وضبط وتنظيم الخدمات الصحية وفقا لمعايير محددة للجودة والاعتماد.
<br>
• تنظيم القطاع الصحي المصري بما يضمن سلامته واستقراره وتنميته وتحسين جودة العمل بما يضمن حقوق المنتفعين، وذلك من خلال التسجيل والاعتماد والرقابة علي المنشآت الطبية وأعضاء المهن الطبية.
</div> -->

 </fieldset>
</div>


</div>




</div>
 







<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->

</body>