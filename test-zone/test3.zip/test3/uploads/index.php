<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>M_G_X_Uploads_Area</title>
</head>
<body>
	<div style="display: grid; justify-content: center;">


		<h2 style="z-index: -1;">M_G_X_Uploads_Area</h2>
		
	</div>
<div style="display: grid; justify-content: center;">
<img src="../img/seo_maintenance_icon_192453.png" style="opacity: 0.8; z-index: -1;">
</div>
</body>
</html>