<?php 

require_once('header.php');
?>
<style type="text/css">
	.spand{

		padding: 10px;
		position: absolute;
		left: 3%;
		top: 100px;
		width: 70%;
		margin: 4px;
		font-size: 30px;
		text-align: center;
		font-weight: bold;
		text-shadow: 10px 10px 20px darkred;
	}
		.spandd{

		padding: 10px;
		position: absolute;
		left: 3%;
	    top: 280px;
		width: 70%;
		margin: 4px;
		font-size: 30px;
		text-align: center;
		font-weight: bold;
		text-shadow: 10px 10px 20px darkred;
		z-index: -1;
		opacity: 0.7;
	}



  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){

}
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){


 	.spand {
    padding: 10px;
    position: absolute;
    left: 3%;
    top: 227px;
    width: 90%;
    margin: 4px;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    text-shadow: 10px 10px 20px darkred;
}



	.spandd{

		padding: 10px;
		position: absolute;
		left: 14%;
        top: 388px;
		/*width: 70%;*/
		margin: 4px;
		font-size: 30px;
		text-align: center;
		font-weight: bold;
		text-shadow: 10px 10px 20px darkred;
		z-index: -1;
		opacity: 0.7;
	}


}

	@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){




.spand {
    padding: 10px;
    position: absolute;
    left: 3%;
    top: 220px;
    width: 90%;
    margin: 4px;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    text-shadow: 10px 10px 20px darkred;
}


.spandd {
   
    padding: 10px;
    position: absolute;
    left: 13%;
    top: 493px;
   /* width: 70%;*/
    margin: 4px;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    text-shadow: 10px 10px 20px darkred;
    z-index: -1;
    opacity: 0.7;
}


}
</style>


<span class="spand" dir="ltr">Your <u>(*_<i>User Level</i>_*)</u> Don't have the permission to Access to this page ! , Kindly refer to your superior.</span>
<div class="spandd" ><img src="img/action_exit_close_remove_13915.png"></div>

<script>setTimeout(function(){ history.back(); }, 5000);</script>